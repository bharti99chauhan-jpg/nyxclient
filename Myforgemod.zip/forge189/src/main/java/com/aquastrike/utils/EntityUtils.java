package com.aquastrike.utils;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.MathHelper;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class EntityUtils {

    private static final Minecraft mc = Minecraft.getMinecraft();

    public enum TargetMode { PLAYERS, MOBS, ANIMALS, ALL }

    public static boolean canTarget(Entity e, TargetMode mode, boolean teams) {
        if (e == null || e == mc.thePlayer || e.isDead) return false;
        if (!(e instanceof EntityLivingBase)) return false;
        EntityLivingBase elb = (EntityLivingBase) e;
        if (elb.getHealth() <= 0) return false;

        if (!teams && e instanceof EntityPlayer) {
            EntityPlayer ep = (EntityPlayer) e;
            if (mc.thePlayer.getTeam() != null
                    && mc.thePlayer.getTeam().isSameTeam(ep.getTeam())) {
                return false;
            }
        }

        switch (mode) {
            case PLAYERS: return e instanceof EntityPlayer;
            case MOBS:    return e instanceof EntityMob;
            case ANIMALS: return e instanceof EntityAnimal;
            default:      return true;
        }
    }

    /** Return entities within {@code range} blocks, sorted by {@code sort}. */
    public static List<EntityLivingBase> getTargets(float range,
                                                    TargetMode mode,
                                                    boolean teams,
                                                    String sort) {
        List<EntityLivingBase> list = new ArrayList<>();
        for (Entity e : mc.theWorld.loadedEntityList) {
            if (!(e instanceof EntityLivingBase)) continue;
            if (!canTarget(e, mode, teams)) continue;
            if (mc.thePlayer.getDistanceToEntity(e) > range) continue;
            list.add((EntityLivingBase) e);
        }

        switch (sort.toLowerCase()) {
            case "distance":
                list.sort(Comparator.comparingDouble(
                        e -> mc.thePlayer.getDistanceToEntity(e)));
                break;
            case "health":
                list.sort(Comparator.comparingDouble(EntityLivingBase::getHealth));
                break;
            case "angle":
                list.sort(Comparator.comparingDouble(e -> {
                    float[] rot = RotationUtils.getRotationsToEntity(e);
                    return RotationUtils.rotationDistance(
                            mc.thePlayer.rotationYaw,  mc.thePlayer.rotationPitch,
                            rot[0], rot[1]);
                }));
                break;
        }
        return list;
    }

    /** Check whether {@code e} is within the player's FOV cone (degrees). */
    public static boolean isInFOV(Entity e, float fov) {
        float[] rot = RotationUtils.getRotationsToEntity(e);
        float diff = RotationUtils.angleDiff(mc.thePlayer.rotationYaw, rot[0]);
        return Math.abs(diff) <= fov / 2f;
    }

    /** Approx. 2-D distance (XZ) from local player. */
    public static double distanceXZ(Entity e) {
        double dx = mc.thePlayer.posX - e.posX;
        double dz = mc.thePlayer.posZ - e.posZ;
        return Math.sqrt(dx * dx + dz * dz);
    }

    /** Rough anti-bot: entities with username-like names appearing < 1 second old. */
    public static boolean isPossiblyBot(EntityPlayer ep) {
        // Very simplified check; real Vape also checks for entity age & movement
        return ep.ticksExisted < 2;
    }
}
