package com.aquastrike.gui;

import com.aquastrike.AquaStrike;
import com.aquastrike.module.Category;
import com.aquastrike.module.Module;
import com.aquastrike.module.setting.BoolSetting;
import com.aquastrike.module.setting.ListSetting;
import com.aquastrike.module.setting.NumberSetting;
import com.aquastrike.module.setting.Setting;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import org.lwjgl.input.Mouse;

import java.io.IOException;
import java.util.List;

/**
 * Simple flat ClickGUI — no shaders, no blur.
 * Layout: category tabs across the top, module list below.
 */
public class ClickGUI extends GuiScreen {

    // ---- colours ------------------------------------------------------------
    private static final int COL_BG       = 0xCC1A1A1A;  // window bg
    private static final int COL_TAB      = 0xFF222222;
    private static final int COL_TAB_SEL  = 0xFF2255AA;
    private static final int COL_MOD_ON   = 0xFF2255AA;
    private static final int COL_MOD_OFF  = 0xFF2D2D2D;
    private static final int COL_MOD_HOV  = 0xFF334466;
    private static final int COL_SETTING  = 0xFF1E1E1E;
    private static final int COL_TEXT     = 0xFFEEEEEE;
    private static final int COL_VAL      = 0xFF8899BB;

    // ---- layout -------------------------------------------------------------
    private static final int TAB_H    = 16;
    private static final int MOD_H    = 16;
    private static final int SET_H    = 14;
    private static final int PANEL_X  = 4;
    private static final int PANEL_Y  = 4;
    private static final int PANEL_W  = 160;

    // ---- state --------------------------------------------------------------
    private Category     selectedCategory = Category.COMBAT;
    private Module       expandedModule   = null;
    private int          scrollOffset     = 0;
    private int          dragSettingSlot  = -1;  // index in expanded module's settings
    private int          dragStartX       = 0;
    private double       dragStartValue   = 0;

    // ---- GuiScreen ----------------------------------------------------------

    @Override
    public boolean doesGuiPauseGame() { return false; }

    @Override
    public void drawScreen(int mouseX, int mouseY, float pt) {
        // ---- draw tabs -------------------------------------------------------
        Category[] cats = Category.values();
        int tabW = PANEL_W / cats.length;
        for (int i = 0; i < cats.length; i++) {
            int tx = PANEL_X + i * tabW;
            boolean sel = cats[i] == selectedCategory;
            drawRect(tx, PANEL_Y, tx + tabW, PANEL_Y + TAB_H,
                     sel ? COL_TAB_SEL : COL_TAB);
            String name = cats[i].name().substring(0, 1)
                        + cats[i].name().substring(1).toLowerCase();
            fontRendererObj.drawString(name,
                    tx + tabW / 2f - fontRendererObj.getStringWidth(name) / 2f,
                    PANEL_Y + 4, COL_TEXT, false);
        }

        // ---- draw module list -----------------------------------------------
        List<Module> mods = AquaStrike.moduleManager.getModulesByCategory(selectedCategory);
        int y = PANEL_Y + TAB_H + 2 - scrollOffset;

        for (Module m : mods) {
            if (y + MOD_H < PANEL_Y + TAB_H) { y += MOD_H; continue; }

            boolean hov = mouseX >= PANEL_X && mouseX < PANEL_X + PANEL_W
                       && mouseY >= y && mouseY < y + MOD_H;
            int bg = m.isEnabled() ? COL_MOD_ON : (hov ? COL_MOD_HOV : COL_MOD_OFF);
            drawRect(PANEL_X, y, PANEL_X + PANEL_W, y + MOD_H, bg);
            fontRendererObj.drawString(m.getName(), PANEL_X + 3, y + 4, COL_TEXT, false);

            String suffix = m.getSuffix();
            if (suffix != null) {
                fontRendererObj.drawString(suffix,
                        PANEL_X + PANEL_W - fontRendererObj.getStringWidth(suffix) - 3,
                        y + 4, COL_VAL, false);
            }
            y += MOD_H;

            // expanded settings
            if (m == expandedModule) {
                for (int si = 0; si < m.getSettings().size(); si++) {
                    Setting<?> s = m.getSettings().get(si);
                    drawRect(PANEL_X, y, PANEL_X + PANEL_W, y + SET_H, COL_SETTING);
                    fontRendererObj.drawString(" " + s.getName(), PANEL_X + 3, y + 3,
                            0xFFAAAAAA, false);
                    // value on right
                    String val = settingValueStr(s);
                    fontRendererObj.drawString(val,
                            PANEL_X + PANEL_W - fontRendererObj.getStringWidth(val) - 3,
                            y + 3, COL_VAL, false);

                    // slider for Number settings
                    if (s instanceof NumberSetting) {
                        NumberSetting ns = (NumberSetting) s;
                        double t = (ns.getValue() - ns.getMin()) / (ns.getMax() - ns.getMin());
                        int barW = (int) (t * (PANEL_W - 6));
                        drawRect(PANEL_X + 3, y + SET_H - 3, PANEL_X + 3 + barW, y + SET_H - 1,
                                COL_TAB_SEL);
                    }
                    y += SET_H;
                }
            }
        }
        super.drawScreen(mouseX, mouseY, pt);
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int button) throws IOException {
        // --- tab click -------------------------------------------------------
        Category[] cats = Category.values();
        int tabW = PANEL_W / cats.length;
        if (mouseY >= PANEL_Y && mouseY < PANEL_Y + TAB_H) {
            for (int i = 0; i < cats.length; i++) {
                int tx = PANEL_X + i * tabW;
                if (mouseX >= tx && mouseX < tx + tabW) {
                    selectedCategory = cats[i];
                    expandedModule   = null;
                    scrollOffset     = 0;
                    return;
                }
            }
        }

        // --- module / setting click ------------------------------------------
        List<Module> mods = AquaStrike.moduleManager.getModulesByCategory(selectedCategory);
        int y = PANEL_Y + TAB_H + 2 - scrollOffset;

        for (Module m : mods) {
            if (mouseY >= y && mouseY < y + MOD_H
                    && mouseX >= PANEL_X && mouseX < PANEL_X + PANEL_W) {
                if (button == 0) {
                    m.toggle();
                } else if (button == 1) {
                    expandedModule = (expandedModule == m) ? null : m;
                }
                return;
            }
            y += MOD_H;

            if (m == expandedModule) {
                for (int si = 0; si < m.getSettings().size(); si++) {
                    Setting<?> s = m.getSettings().get(si);
                    if (mouseY >= y && mouseY < y + SET_H
                            && mouseX >= PANEL_X && mouseX < PANEL_X + PANEL_W) {
                        handleSettingClick(s, button, mouseX, si);
                        return;
                    }
                    y += SET_H;
                }
            }
        }
        super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public void handleMouseInput() throws IOException {
        super.handleMouseInput();
        int scroll = Mouse.getEventDWheel();
        if (scroll != 0) scrollOffset -= scroll / 2;
        if (scrollOffset < 0) scrollOffset = 0;
    }

    // ---- helpers ------------------------------------------------------------

    @SuppressWarnings({"unchecked","rawtypes"})
    private void handleSettingClick(Setting<?> s, int button, int mouseX, int slot) {
        if (s instanceof BoolSetting) {
            ((BoolSetting) s).toggle();
        } else if (s instanceof ListSetting) {
            if (button == 0)      ((ListSetting) s).cycle();
        } else if (s instanceof NumberSetting) {
            NumberSetting ns = (NumberSetting) s;
            if (button == 0) {
                dragSettingSlot = slot;
                dragStartX      = mouseX;
                dragStartValue  = ns.getValue();
            } else if (button == 1) {
                ns.setValue(ns.getMin() + (ns.getMax() - ns.getMin()) / 2.0);
            }
        }
    }

    private String settingValueStr(Setting<?> s) {
        if (s instanceof BoolSetting)   return ((BoolSetting) s).isEnabled() ? "§aON" : "§cOFF";
        if (s instanceof ListSetting)   return ((ListSetting) s).getValue();
        if (s instanceof NumberSetting) {
            double v = ((NumberSetting) s).getValue();
            return v == Math.floor(v) ? String.valueOf((int) v)
                                      : String.format("%.1f", v);
        }
        return s.getValue().toString();
    }
}
