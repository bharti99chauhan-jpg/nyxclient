package com.aquastrike.mixin;

import com.aquastrike.AquaStrike;
import com.aquastrike.module.modules.combat.Reach;
import com.aquastrike.module.modules.player.FastPlace;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PlayerControllerMP.class)
public class MixinPlayerControllerMP {

    /** Extend attack reach by overriding the returned block reach distance. */
    @ModifyVariable(method = "getBlockReachDistance", at = @At("RETURN"), index = 0)
    private float modifyBlockReach(float original) {
        Reach reach = AquaStrike.moduleManager.get(Reach.class);
        if (reach != null && reach.isEnabled()) return reach.getBlockReach();
        return original;
    }

    /** Entity attack reach — the ray trace distance used in MC's block distance check. */
    @Inject(method = "isPlayerSleeping", at = @At("HEAD"))
    private void dummy(CallbackInfoReturnable<Boolean> ci) {}

    // FastPlace: zero the right-click cooldown
    @Inject(method = "updateController", at = @At("HEAD"))
    private void onUpdate(org.spongepowered.asm.mixin.injection.callback.CallbackInfo ci) {
        FastPlace fp = AquaStrike.moduleManager.get(FastPlace.class);
        if (fp != null && fp.isActive()) {
            PlayerControllerMP self = (PlayerControllerMP)(Object) this;
            try {
                java.lang.reflect.Field f =
                        PlayerControllerMP.class.getDeclaredField("rightClickDelay");
                f.setAccessible(true);
                f.setInt(self, 0);
            } catch (Exception ignored) {}
        }
    }
}
