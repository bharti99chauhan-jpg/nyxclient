package com.aquastrike.module.modules.combat;

import com.aquastrike.event.EventTarget;
import com.aquastrike.event.events.EventMotion;
import com.aquastrike.module.Category;
import com.aquastrike.module.Module;
import com.aquastrike.module.setting.BoolSetting;
import com.aquastrike.module.setting.NumberSetting;
import com.aquastrike.utils.RotationUtils;
import net.minecraft.block.Block;
import net.minecraft.block.BlockAir;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.item.ItemTool;
import net.minecraft.util.MovingObjectPosition;
import org.lwjgl.input.Mouse;

/**
 * AutoClicker — fires left and/or right clicks at a Gaussian-distributed CPS.
 *
 * Polar / anti-cheat considerations:
 *  - Gaussian CPS distribution (not uniform random) matches human variance.
 *  - CPS min/max rather than a fixed value adds the expected spread.
 *  - InventoryCheck: won't click when the inventory GUI is open.
 *  - WeaponOnly: only clicks when holding a sword/tool.
 *  - BlockBreak: left-click CPS reduces while breaking a block so it doesn't
 *    interrupt the break animation in an obviously automated way.
 *  - Clicks are simulated via KeyBinding.setKeyBindState + onTick,
 *    matching exactly what the vanilla client sends.
 */
public class AutoClicker extends Module {

    // ---- settings -----------------------------------------------------------
    private final BoolSetting   leftClick    = add(new BoolSetting("LeftClick",   true));
    private final NumberSetting leftMin      = add(new NumberSetting("L.MinCPS",  10, 1, 20, 1));
    private final NumberSetting leftMax      = add(new NumberSetting("L.MaxCPS",  14, 1, 20, 1));

    private final BoolSetting   rightClick   = add(new BoolSetting("RightClick",  false));
    private final NumberSetting rightMin     = add(new NumberSetting("R.MinCPS",  8,  1, 20, 1));
    private final NumberSetting rightMax     = add(new NumberSetting("R.MaxCPS",  12, 1, 20, 1));

    private final BoolSetting   weaponOnly   = add(new BoolSetting("WeaponOnly",  true));
    private final BoolSetting   invCheck     = add(new BoolSetting("InvCheck",    true));
    private final BoolSetting   blockBreak   = add(new BoolSetting("BlockBreak",  true));
    private final BoolSetting   onlyOnTarget = add(new BoolSetting("OnlyTarget",  false));

    // ---- state --------------------------------------------------------------
    private long nextLeftClick  = 0;
    private long nextRightClick = 0;

    public AutoClicker() {
        super("AutoClicker", Category.COMBAT);
    }

    @EventTarget
    public void onMotion(EventMotion event) {
        if (!event.isPre()) return;
        if (mc.thePlayer == null || mc.theWorld == null) return;

        // inventory open → skip
        if (invCheck.isEnabled() && mc.currentScreen != null) return;

        // weapon check
        if (weaponOnly.isEnabled() && !isHoldingWeapon()) return;

        long now = System.currentTimeMillis();

        // ---- LEFT CLICK -------------------------------------------------------
        if (leftClick.isEnabled()) {
            if (now >= nextLeftClick) {
                // suppress if OnlyTarget and KA has no target
                if (!shouldClickLeft()) {
                    scheduleLeft();
                } else {
                    doLeftClick();
                    scheduleLeft();
                }
            }
        }

        // ---- RIGHT CLICK ------------------------------------------------------
        if (rightClick.isEnabled()) {
            if (now >= nextRightClick) {
                doRightClick();
                scheduleRight();
            }
        }
    }

    // ---- click actions ------------------------------------------------------

    private void doLeftClick() {
        // block-break mode: if already breaking, just hold the button
        if (blockBreak.isEnabled()) {
            MovingObjectPosition mop = mc.objectMouseOver;
            if (mop != null && mop.typeOfHit == MovingObjectPosition.MovingObjectType.BLOCK) {
                // hold LMB — the game handles block breaking
                KeyBinding.setKeyBindState(mc.gameSettings.keyBindAttack.getKeyCode(), true);
                KeyBinding.onTick(mc.gameSettings.keyBindAttack.getKeyCode());
                return;
            }
        }
        // attack entity / left-click action
        mc.leftClickCounter = 0;
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindAttack.getKeyCode(), true);
        KeyBinding.onTick(mc.gameSettings.keyBindAttack.getKeyCode());
        // release next tick (we'll toggle it off on next event fire)
    }

    private void doRightClick() {
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindUseItem.getKeyCode(), true);
        KeyBinding.onTick(mc.gameSettings.keyBindUseItem.getKeyCode());
    }

    // ---- scheduling ---------------------------------------------------------

    private void scheduleLeft() {
        double minCPS = leftMin.getValue();
        double maxCPS = leftMax.getValue();
        double ms     = gaussianMs(minCPS, maxCPS);
        nextLeftClick = System.currentTimeMillis() + (long) ms;
    }

    private void scheduleRight() {
        double minCPS = rightMin.getValue();
        double maxCPS = rightMax.getValue();
        double ms     = gaussianMs(minCPS, maxCPS);
        nextRightClick = System.currentTimeMillis() + (long) ms;
    }

    /**
     * Convert a CPS range into a millisecond delay using a Gaussian distribution.
     * Mean CPS = (min + max) / 2, sigma chosen so 3σ ≈ range/2.
     */
    private double gaussianMs(double minCPS, double maxCPS) {
        if (minCPS > maxCPS) { double t = minCPS; minCPS = maxCPS; maxCPS = t; }
        double meanCPS  = (minCPS + maxCPS) * 0.5;
        double sigma    = (maxCPS - minCPS) / 6.0 + 0.1; // sigma so range ≈ 6σ
        double actualCPS = RotationUtils.gaussian((float) meanCPS, (float) sigma);
        actualCPS = Math.max(1, Math.min(20, actualCPS));
        return 1000.0 / actualCPS;
    }

    // ---- guards -------------------------------------------------------------

    private boolean shouldClickLeft() {
        if (!onlyOnTarget.isEnabled()) return true;
        // check if KA is tracking a target
        for (Object o : mc.theWorld.loadedEntityList) {
            // simple: return true if any entity within range
            if (o instanceof net.minecraft.entity.EntityLivingBase) {
                net.minecraft.entity.EntityLivingBase e =
                        (net.minecraft.entity.EntityLivingBase) o;
                if (e == mc.thePlayer) continue;
                if (mc.thePlayer.getDistanceToEntity(e) <= 4.5f) return true;
            }
        }
        return false;
    }

    private boolean isHoldingWeapon() {
        ItemStack held = mc.thePlayer.getHeldItem();
        if (held == null) return false;
        return held.getItem() instanceof ItemSword
            || held.getItem() instanceof ItemTool;
    }

    @Override
    public String getSuffix() {
        double min = leftMin.getValue();
        double max = leftMax.getValue();
        return (int)min + "-" + (int)max;
    }
}
