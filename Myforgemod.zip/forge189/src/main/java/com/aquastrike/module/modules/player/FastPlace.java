package com.aquastrike.module.modules.player;

import com.aquastrike.module.Category;
import com.aquastrike.module.Module;

public class FastPlace extends Module {
    public FastPlace() { super("FastPlace", Category.PLAYER); }

    // Applied in MixinPlayerControllerMP by zeroing the right-click delay
    public boolean isActive() { return isEnabled(); }
}
