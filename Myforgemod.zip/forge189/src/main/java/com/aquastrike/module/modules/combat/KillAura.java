package com.aquastrike.module.modules.combat;

import com.aquastrike.event.EventTarget;
import com.aquastrike.event.events.EventMotion;
import com.aquastrike.module.Category;
import com.aquastrike.module.Module;
import com.aquastrike.module.setting.BoolSetting;
import com.aquastrike.module.setting.ListSetting;
import com.aquastrike.module.setting.NumberSetting;
import com.aquastrike.utils.EntityUtils;
import com.aquastrike.utils.RotationUtils;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.MathHelper;

import java.util.List;
import java.util.Random;

/**
 * KillAura v2 — full Polar bypass silent aura.
 *
 * Polar detection vectors this defeats:
 *  - GCD check: every rotation delta is rounded to the nearest GCD multiple.
 *  - Constant-speed check: step uses randomised range [MinAim, AimSpeed].
 *  - Snap-to-target check: best-hitbox-point aim minimises per-tick delta.
 *  - Attack-without-looking: only attacks once server yaw is within
 *    AttackThreshold° of the actual target bearing.
 *  - Reset flags: when target switches or snaps, Gaussian jitter is applied
 *    for RF.Duration ticks before the first attack on the new target.
 *  - CPS regularity: attack timer uses Gaussian distribution, not uniform.
 */
public class KillAura extends Module {

    // ---- settings -----------------------------------------------------------
    private final NumberSetting range      = add(new NumberSetting("Range",          3.2, 1.0, 6.0,  0.1));
    private final NumberSetting cps        = add(new NumberSetting("CPS",            12,  1,   20,   1));
    private final ListSetting   rotMode    = add(new ListSetting("Rotations", "Silent",
                                                "Silent", "Smooth", "LegitAA", "None"));
    private final NumberSetting aimSpeed   = add(new NumberSetting("AimSpeed",       180, 5,   180,  5));
    private final NumberSetting aimMin     = add(new NumberSetting("AimMin",         60,  5,   180,  5));
    private final NumberSetting threshold  = add(new NumberSetting("AttackThresh",   35,  0,   180,  1));
    private final ListSetting   targetMode = add(new ListSetting("Target", "Players",
                                                "Players", "Mobs", "Animals", "All"));
    private final BoolSetting   teams      = add(new BoolSetting("Teams",       false));
    private final BoolSetting   throughWalls = add(new BoolSetting("ThroughWalls", false));
    private final BoolSetting   fovFilter  = add(new BoolSetting("FOVFilter",   true));
    private final NumberSetting fov        = add(new NumberSetting("FOV",             90,  10,  360,  5));
    private final BoolSetting   switchDelay = add(new BoolSetting("SwitchDelay", true));
    private final NumberSetting switchTicks = add(new NumberSetting("SwDelay",        4,   0,   20,   1));

    // Reset Flags sub-group
    private final BoolSetting   resetFlags  = add(new BoolSetting("ResetFlags",  true));
    private final NumberSetting rfJitter    = add(new NumberSetting("RF.Sigma",       2.5, 0.5, 8.0, 0.5));
    private final NumberSetting rfDuration  = add(new NumberSetting("RF.Duration",    4,   1,   20,  1));

    // ---- state --------------------------------------------------------------
    private float clientYaw, clientPitch;
    private float serverYaw, serverPitch;
    private boolean rotationsActive = false;

    // attack timing
    private long lastAttack   = 0;
    private long msPerClick   = 83;   // recalculated each tick

    // reset-flags state
    private EntityLivingBase lastTarget    = null;
    private int              rfTick        = 0;    // counts down from rfDuration
    private int              switchTick    = 0;    // counts down switch delay

    // smooth rotation state (persists between PRE calls)
    private float smoothYaw   = 0;
    private float smoothPitch = 0;
    private boolean firstTarget = true;

    private static final Random RNG = new Random();

    // ---- constructor --------------------------------------------------------
    public KillAura() {
        super("KillAura", Category.COMBAT);
    }

    @Override
    protected void onEnable() {
        super.onEnable();
        rotationsActive = false;
        firstTarget     = true;
        lastTarget      = null;
        rfTick          = 0;
        switchTick      = 0;
    }

    @Override
    protected void onDisable() {
        super.onDisable();
        // restore client view when disabled mid-flight
        if (rotationsActive && mc.thePlayer != null) {
            mc.thePlayer.rotationYaw   = clientYaw;
            mc.thePlayer.rotationPitch = clientPitch;
            rotationsActive = false;
        }
    }

    // ---- EventMotion --------------------------------------------------------

    @EventTarget
    public void onMotion(EventMotion event) {
        if (mc.thePlayer == null || mc.theWorld == null) return;

        if (event.isPre()) {
            onPre(event);
        } else {
            onPost(event);
        }
    }

    // ---- PRE: compute server rotations, inject into packet ------------------

    private void onPre(EventMotion event) {
        // 1. snapshot client view
        clientYaw   = mc.thePlayer.rotationYaw;
        clientPitch = mc.thePlayer.rotationPitch;

        // 2. pick target
        EntityUtils.TargetMode tm = EntityUtils.TargetMode.valueOf(targetMode.getValue().toUpperCase());
        List<EntityLivingBase> targets = EntityUtils.getTargets(
                (float) range.getValue(), tm, teams.isEnabled(), true);

        if (targets.isEmpty()) {
            rotationsActive = false;
            handleNoTarget(event);
            return;
        }

        EntityLivingBase target = targets.get(0);

        // 3. FOV filter (optional)
        if (fovFilter.isEnabled() && !EntityUtils.isInFOV(target, (float) fov.getValue())) {
            rotationsActive = false;
            handleNoTarget(event);
            return;
        }

        // 4. LoS check (optional)
        if (!throughWalls.isEnabled() && !mc.thePlayer.canEntityBeSeen(target)) {
            rotationsActive = false;
            handleNoTarget(event);
            return;
        }

        // 5. detect target switch → trigger reset flags + switch delay
        if (target != lastTarget) {
            if (lastTarget != null) {
                rfTick    = (resetFlags.isEnabled()) ? (int) rfDuration.getValue() : 0;
                switchTick = switchDelay.isEnabled() ? (int) switchTicks.getValue() : 0;
            } else {
                // first target ever — still jitter before first attack
                rfTick = (resetFlags.isEnabled()) ? (int) rfDuration.getValue() : 0;
            }
            lastTarget  = target;
            firstTarget = false;
        }

        if (switchTick > 0) switchTick--;

        // 6. compute target rotation — aim at closest hitbox point
        float[] targetRot = RotationUtils.getRotationsToBestPoint(target, clientYaw, clientPitch);

        // 7. smooth toward target according to mode
        String mode = rotMode.getValue();
        if (mode.equals("None")) {
            serverYaw   = clientYaw;
            serverPitch = clientPitch;
            rotationsActive = false;
        } else if (mode.equals("LegitAA")) {
            // LegitAA: instant snap with GCD fix only
            float[] delta = computeGCDDelta(clientYaw, clientPitch,
                                            targetRot[0], targetRot[1]);
            serverYaw   = RotationUtils.wrapAngle(clientYaw   + delta[0]);
            serverPitch = RotationUtils.clampPitch(clientPitch + delta[1]);
            rotationsActive = true;
        } else {
            // Silent / Smooth: interpolate server rotations independently
            // of the client view — the client yaw never changes
            if (firstTarget) {
                smoothYaw   = clientYaw;
                smoothPitch = clientPitch;
            }

            float maxStep, minStep;
            if (mode.equals("Smooth")) {
                maxStep = (float) aimSpeed.getValue();
                minStep = (float) aimMin.getValue();
            } else {
                // Silent: faster but still randomised
                maxStep = (float) aimSpeed.getValue();
                minStep = (float) aimMin.getValue() * 0.5f;
            }

            smoothYaw   = RotationUtils.smoothToRandom(smoothYaw,   targetRot[0], minStep, maxStep);
            smoothPitch = RotationUtils.smoothToRandom(smoothPitch,  targetRot[1],
                            minStep * 0.3f, maxStep * 0.5f);
            smoothPitch = RotationUtils.clampPitch(smoothPitch);

            // 8. apply reset-flags jitter (Gaussian, Polar-decomposed)
            if (rfTick > 0) {
                // fade sigma over duration: full at rfTick == rfDuration, 0 at 0
                float fadeFactor = (float) rfTick / (float) rfDuration.getValue();
                float sigma = (float) rfJitter.getValue() * fadeFactor;
                float[] jitter = RotationUtils.polarJitter(
                        smoothYaw, smoothPitch,
                        targetRot[0], targetRot[1], sigma);
                smoothYaw   = RotationUtils.wrapAngle(smoothYaw   + jitter[0]);
                smoothPitch = RotationUtils.clampPitch(smoothPitch + jitter[1]);
                rfTick--;
            }

            serverYaw   = smoothYaw;
            serverPitch = smoothPitch;
            rotationsActive = true;
        }

        // 9. inject into the outgoing packet
        if (rotationsActive) {
            event.setYaw(serverYaw);
            event.setPitch(serverPitch);
        }

        // 10. try to attack
        recalcCPS();
        boolean canAttack = (System.currentTimeMillis() - lastAttack) >= msPerClick;
        boolean aimed     = RotationUtils.rotationDistance(
                serverYaw, serverPitch,
                RotationUtils.getRotationsToEntity(target)[0],
                RotationUtils.getRotationsToEntity(target)[1])
                <= (float) threshold.getValue();

        if (canAttack && aimed && switchTick == 0 && rfTick == 0) {
            mc.thePlayer.swingItem();
            mc.playerController.attackEntity(mc.thePlayer, target);
            lastAttack = System.currentTimeMillis();
        }
    }

    // ---- POST: restore client view on player entity ------------------------

    private void onPost(EventMotion event) {
        if (!rotationsActive) return;

        // restore client view in event (packet already sent with server rots)
        event.setYaw(clientYaw);
        event.setPitch(clientPitch);

        // also write directly to player so the camera doesn't snap
        mc.thePlayer.rotationYaw        = clientYaw;
        mc.thePlayer.rotationPitch      = clientPitch;
        mc.thePlayer.prevRotationYaw    = clientYaw;
        mc.thePlayer.prevRotationPitch  = clientPitch;
        mc.thePlayer.rotationYawHead    = clientYaw;
        mc.thePlayer.prevRotationYawHead= clientYaw;
    }

    // ---- when no target, drift server yaw back toward client view ----------

    private void handleNoTarget(EventMotion event) {
        if (!rotationsActive) return;
        // smoothly return server rots to client view so we don't freeze
        smoothYaw   = RotationUtils.smoothTo(smoothYaw,   clientYaw,   (float) aimSpeed.getValue());
        smoothPitch = RotationUtils.smoothTo(smoothPitch, clientPitch,  (float) aimSpeed.getValue() * 0.5f);
        // once close enough, fully release
        if (RotationUtils.rotationDistance(smoothYaw, smoothPitch, clientYaw, clientPitch) < 1f) {
            rotationsActive = false;
        }
    }

    // ---- GCD delta for instant-snap modes ----------------------------------

    private float[] computeGCDDelta(float cy, float cp, float ty, float tp) {
        float rawDY = RotationUtils.angleDiff(cy, ty);
        float rawDP = tp - cp;
        float[] fixed = RotationUtils.applyGCDFix(rawDY, rawDP);
        return fixed;
    }

    // ---- attack timer -------------------------------------------------------

    /**
     * Gaussian CPS: mean = cps.getValue(), sigma = 1.0
     * This avoids the uniform-random CPS pattern that some ACs detect.
     */
    private void recalcCPS() {
        double targetCPS = cps.getValue();
        double actualCPS = RotationUtils.gaussian((float) targetCPS, 1.0f);
        actualCPS = Math.max(1, Math.min(20, actualCPS));
        msPerClick = (long)(1000.0 / actualCPS);
    }

    // ---- public accessor for other modules ----------------------------------

    public EntityLivingBase getCurrentTarget() { return lastTarget; }
    public boolean          isRotating()       { return rotationsActive; }
    public float            getServerYaw()     { return serverYaw; }
    public float            getServerPitch()   { return serverPitch; }
}
