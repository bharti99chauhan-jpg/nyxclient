package com.portolan;

import com.portolan.event.EventBus;
import com.portolan.gui.ClickGUI;
import com.portolan.module.ModuleManager;
import net.minecraft.client.Minecraft;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

/**
 * Portolan — Minecraft 1.8.9 Mixin client.
 *
 * Entry point; initialises EventBus and ModuleManager, registers the
 * Forge tick/key hooks, and handles GUI open.
 */
@Mod(
    modid   = PortolanClient.MODID,
    name    = PortolanClient.NAME,
    version = PortolanClient.VERSION
)
public class PortolanClient {

    public static final String MODID   = "portolan";
    public static final String NAME    = "Portolan";
    public static final String VERSION = "1.0.0";

    // ── Statics accessible from anywhere ─────────────────────────────────────
    public static EventBus     eventBus;
    public static ModuleManager moduleManager;
    public static ClickGUI      clickGUI;

    private static final Minecraft mc = Minecraft.getMinecraft();

    // ── Singleton ────────────────────────────────────────────────────────────
    private static PortolanClient instance;
    public  static PortolanClient getInstance() { return instance; }

    // ── FML init ─────────────────────────────────────────────────────────────

    @EventHandler
    public void init(FMLInitializationEvent event) {
        instance      = this;
        eventBus      = new EventBus();
        moduleManager = new ModuleManager();
        clickGUI      = new ClickGUI();

        // Register the Portolan instance as a Forge event listener so we can
        // catch TickEvent and InputEvent without a separate class.
        MinecraftForge.EVENT_BUS.register(this);

        System.out.println("[Portolan] " + NAME + " " + VERSION + " initialised.");
    }

    @EventHandler
    public void postInit(FMLPostInitializationEvent event) {
        // Any post-init work (config load, etc.) goes here.
    }

    // ── Forge game tick — module onUpdate ─────────────────────────────────────

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.START) return;
        if (mc.thePlayer == null || mc.theWorld == null) return;

        for (var m : moduleManager.getAll()) {
            if (m.isEnabled()) m.onUpdate();
        }
    }

    // ── Keyboard — open GUI on INSERT (or RSHIFT on Android) ─────────────────

    @SubscribeEvent
    public void onKeyInput(InputEvent.KeyInputEvent event) {
        if (!Keyboard.getEventKeyState()) return;

        int key = Keyboard.getEventKey();

        // GUI open key — INSERT on desktop, adapt to RSHIFT for touch layouts
        if (key == Keyboard.KEY_INSERT || key == Keyboard.KEY_RSHIFT) {
            if (mc.currentScreen instanceof ClickGUI) {
                mc.displayGuiScreen(null);
            } else {
                mc.displayGuiScreen(clickGUI);
            }
            return;
        }

        // Module hotkeys
        moduleManager.onKey(key);
    }
}
