package com.portolan.gui;

import com.portolan.PortolanClient;
import com.portolan.module.Category;
import com.portolan.module.Module;
import com.portolan.module.setting.BoolSetting;
import com.portolan.module.setting.ListSetting;
import com.portolan.module.setting.NumberSetting;
import com.portolan.module.setting.Setting;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import org.lwjgl.opengl.GL11;

import java.awt.*;
import java.io.IOException;
import java.util.List;

/**
 * Minimal touch-friendly ClickGUI.
 *
 * Layout:
 *   One column per Category across the top of the screen.
 *   Clicking a category header expands that column downward.
 *   Clicking a module name toggles it.
 *   Expanded modules show their settings below.
 *   NumberSetting: tap +/- either side to increment by 0.1.
 *   BoolSetting: tap the value label to toggle.
 *   ListSetting: tap the value label to cycle.
 *
 * Scaled to work on a typical Android screen (360–414 dp wide).
 * No external assets required — font renderer only.
 */
public class ClickGUI extends GuiScreen {

    private static final int   COL_W    = 110;  // px per category column
    private static final int   ROW_H    = 14;   // px per row
    private static final int   PAD      = 4;
    private static final Color BG       = new Color(20, 20, 20, 210);
    private static final Color HDR      = new Color(40, 40, 60, 230);
    private static final Color ON       = new Color(80, 160, 255, 255);
    private static final Color OFF      = new Color(100, 100, 100, 255);
    private static final Color SETTING  = new Color(55, 55, 55, 220);
    private static final Color TEXT     = new Color(220, 220, 220, 255);

    /** Which category is currently expanded (-1 = none). */
    private int expandedCategory = -1;
    /** Which module is expanded to show settings (null = none). */
    private Module expandedModule = null;

    private final Category[] cats = Category.values();

    // ── Render ────────────────────────────────────────────────────────────────

    @Override
    public void drawScreen(int mx, int my, float pt) {
        ScaledResolution sr = new ScaledResolution(mc);

        // Dim background
        drawRect(0, 0, sr.getScaledWidth(), sr.getScaledHeight(), new Color(0, 0, 0, 100).getRGB());

        for (int ci = 0; ci < cats.length; ci++) {
            int x = PAD + ci * (COL_W + PAD);
            drawColumn(ci, x, 10, mx, my);
        }

        super.drawScreen(mx, my, pt);
    }

    private void drawColumn(int catIndex, int x, int y, int mx, int my) {
        Category cat = cats[catIndex];

        // Header
        drawRect(x, y, x + COL_W, y + ROW_H, HDR.getRGB());
        mc.fontRendererObj.drawString(cat.getDisplay(), x + PAD, y + 3, ON.getRGB());
        y += ROW_H;

        if (expandedCategory != catIndex) return;

        List<Module> mods = PortolanClient.moduleManager.byCategory(cat);
        for (Module m : mods) {
            int rowColor = m.isEnabled() ? new Color(30, 60, 90, 220).getRGB() : BG.getRGB();
            drawRect(x, y, x + COL_W, y + ROW_H, rowColor);
            int txtColor = m.isEnabled() ? ON.getRGB() : OFF.getRGB();
            mc.fontRendererObj.drawString(m.getName(), x + PAD, y + 3, txtColor);
            y += ROW_H;

            // Settings for expanded module
            if (expandedModule == m) {
                for (Setting<?> s : m.getSettings()) {
                    drawRect(x, y, x + COL_W, y + ROW_H, SETTING.getRGB());
                    String label = s.getName() + ": ";
                    mc.fontRendererObj.drawString(label, x + PAD + 4, y + 3, TEXT.getRGB());

                    if (s instanceof NumberSetting) {
                        NumberSetting ns = (NumberSetting) s;
                        String val = String.format("%.2f", ns.getValue());
                        mc.fontRendererObj.drawString("< " + val + " >", x + COL_W - 60, y + 3, ON.getRGB());
                    } else if (s instanceof BoolSetting) {
                        BoolSetting bs = (BoolSetting) s;
                        mc.fontRendererObj.drawString(bs.isEnabled() ? "ON" : "OFF",
                                x + COL_W - 24, y + 3, bs.isEnabled() ? ON.getRGB() : OFF.getRGB());
                    } else if (s instanceof ListSetting) {
                        ListSetting ls = (ListSetting) s;
                        mc.fontRendererObj.drawString(ls.getValue(), x + COL_W - 50, y + 3, ON.getRGB());
                    }
                    y += ROW_H;
                }
            }
        }
    }

    // ── Mouse click ───────────────────────────────────────────────────────────

    @Override
    protected void mouseClicked(int mx, int my, int button) throws IOException {
        super.mouseClicked(mx, my, button);

        for (int ci = 0; ci < cats.length; ci++) {
            int x = PAD + ci * (COL_W + PAD);
            int y = 10;

            // Category header hit
            if (inBounds(mx, my, x, y, COL_W, ROW_H)) {
                expandedCategory = (expandedCategory == ci) ? -1 : ci;
                expandedModule   = null;
                return;
            }
            y += ROW_H;
            if (expandedCategory != ci) continue;

            List<Module> mods = PortolanClient.moduleManager.byCategory(cats[ci]);
            for (Module m : mods) {
                if (inBounds(mx, my, x, y, COL_W, ROW_H)) {
                    // Right-click: expand settings; left-click: toggle
                    if (button == 1) {
                        expandedModule = (expandedModule == m) ? null : m;
                    } else {
                        m.toggle();
                    }
                    return;
                }
                y += ROW_H;

                if (expandedModule == m) {
                    for (Setting<?> s : m.getSettings()) {
                        if (inBounds(mx, my, x, y, COL_W, ROW_H)) {
                            handleSettingClick(s, mx, x, COL_W);
                            return;
                        }
                        y += ROW_H;
                    }
                }
            }
        }
    }

    private void handleSettingClick(Setting<?> s, int mx, int colX, int colW) {
        if (s instanceof BoolSetting) {
            ((BoolSetting) s).toggle();
        } else if (s instanceof ListSetting) {
            ((ListSetting) s).cycle();
        } else if (s instanceof NumberSetting) {
            NumberSetting ns = (NumberSetting) s;
            // Tap left half → decrement, right half → increment
            boolean isLeft = mx < colX + colW / 2;
            double  step   = (ns.getMax() - ns.getMin()) > 10 ? 1.0 : 0.1;
            ns.setValue(ns.getValue() + (isLeft ? -step : step));
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private boolean inBounds(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx <= x + w && my >= y && my <= y + h;
    }

    private void drawRect(int x, int y, int x2, int y2, int color) {
        GuiScreen.drawRect(x, y, x2, y2, color);
    }

    @Override
    public boolean doesGuiPauseGame() { return false; }
}
