package com.portolan.module.setting;

import java.util.Arrays;
import java.util.List;

public class ListSetting extends Setting<String> {
    private final List<String> options;

    public ListSetting(String name, String def, String... options) {
        super(name, def);
        this.options = Arrays.asList(options);
    }

    public List<String> getOptions() { return options; }

    public boolean is(String s) { return value.equalsIgnoreCase(s); }

    public void cycle() {
        int idx = options.indexOf(value);
        value = options.get((idx + 1) % options.size());
    }
}
