package com.portolan.module.modules.movement;

import com.portolan.event.EventTarget;
import com.portolan.event.events.EventMotion;
import com.portolan.module.Category;
import com.portolan.module.Module;
import com.portolan.module.setting.ListSetting;
import com.portolan.module.setting.NumberSetting;
import com.portolan.utils.MovementUtils;
import org.lwjgl.input.Keyboard;

/**
 * Speed — Polar-bypass.
 *
 * Mode "Strafe"  (LiquidBounce approach):
 *   POST event: scale existing horizontal velocity toward target speed at a
 *   capped ramp rate.  Vanilla computed the direction + base speed; we just
 *   multiply.  The acceleration profile matches vanilla's curve shape — Polar's
 *   derivative check passes.  Max safe scale: ~1.3× base (~0.26 b/t vs 0.20 b/t).
 *
 * Mode "BHop":
 *   Jump on every ground frame, then in air apply the same post-physics scale.
 *   The jump frame itself is untouched — no horizontal injection on the same tick
 *   as the Y impulse (that simultaneous spike is what the original client triggers).
 *
 * Mode "Vanilla":
 *   Same as BHop but no extra scaling — just the speed from maintaining air momentum.
 */
public class Speed extends Module {

    private final ListSetting   mode  = new ListSetting("Mode", "Strafe", "Strafe", "BHop", "Vanilla");
    private final NumberSetting speed = new NumberSetting("Speed", 0.28, 0.21, 0.6);

    // Ramp state — reset on ground touch so we re-accelerate each air segment
    private double currentScale = 0.0;
    private boolean wasOnGround = true;

    public Speed() {
        super("Speed", Category.MOVEMENT, "Move faster", Keyboard.KEY_X);
        settings.add(mode);
        settings.add(speed);
    }

    @Override
    public void onEnable()  { currentScale = 0.0; }
    @Override
    public void onDisable() { currentScale = 0.0; }

    @EventTarget
    public void onMotion(EventMotion event) {
        if (mc.thePlayer == null) return;
        if (!MovementUtils.isMoving()) return;

        boolean onGround = mc.thePlayer.onGround;

        // Reset ramp when player lands
        if (onGround && !wasOnGround) currentScale = 0.0;
        wasOnGround = onGround;

        switch (mode.getValue()) {

            case "BHop":
                if (onGround && event.isPre()) {
                    // Jump — do not modify horizontal motion this tick
                    mc.thePlayer.jump();
                    return;
                }
                // Fall through to scale in POST while airborne
                if (!event.isPost() || onGround) return;
                applyScale();
                break;

            case "Strafe":
                if (!event.isPost()) return;
                applyScale();
                break;

            case "Vanilla":
                if (onGround && event.isPre()) {
                    mc.thePlayer.jump();
                }
                break;
        }
    }

    private void applyScale() {
        double target   = speed.getValue();
        double curSpeed = MovementUtils.getHorizSpeed(mc.thePlayer);
        if (curSpeed < 0.001) return;

        // Ramp: max 0.03 b/t increase — avoids spike flag
        double newSpeed = Math.min(target, curSpeed + 0.03);
        if (newSpeed <= curSpeed) return;

        double factor = newSpeed / curSpeed;
        mc.thePlayer.motionX *= factor;
        mc.thePlayer.motionZ *= factor;
        currentScale = newSpeed;
    }
}
