package com.portolan.module.modules.render;

import com.portolan.module.Category;
import com.portolan.module.Module;
import org.lwjgl.input.Keyboard;

public class FullBright extends Module {
    private float savedGamma;

    public FullBright() { super("FullBright", Category.RENDER, "Maximum brightness", Keyboard.KEY_NONE); }

    @Override
    public void onEnable()  { savedGamma = mc.gameSettings.gammaSetting; mc.gameSettings.gammaSetting = 100f; }
    @Override
    public void onDisable() { mc.gameSettings.gammaSetting = savedGamma; }
}
