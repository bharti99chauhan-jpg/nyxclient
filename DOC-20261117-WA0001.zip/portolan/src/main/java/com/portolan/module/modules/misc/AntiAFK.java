package com.portolan.module.modules.misc;

import com.portolan.event.EventTarget;
import com.portolan.event.events.EventMotion;
import com.portolan.module.Category;
import com.portolan.module.Module;
import org.lwjgl.input.Keyboard;

public class AntiAFK extends Module {

    private int tick = 0;

    public AntiAFK() { super("AntiAFK", Category.MISC, "Prevent AFK kick", Keyboard.KEY_NONE); }

    @EventTarget
    public void onMotion(EventMotion event) {
        if (!event.isPre() || mc.thePlayer == null) return;
        tick++;
        // Rotate slightly every 60 ticks
        if (tick % 60 == 0) {
            mc.thePlayer.rotationYaw += (tick % 120 == 0) ? 5 : -5;
        }
    }
}
