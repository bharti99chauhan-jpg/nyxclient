package com.portolan.module.modules.misc;

import com.portolan.event.EventTarget;
import com.portolan.event.events.EventSendPacket;
import com.portolan.module.Category;
import com.portolan.module.Module;
import net.minecraft.network.Packet;
import org.lwjgl.input.Keyboard;

import java.util.ArrayList;
import java.util.List;

public class Blink extends Module {

    private final List<Packet<?>> buffer = new ArrayList<>();

    public Blink() { super("Blink", Category.MISC, "Buffer then flush position packets", Keyboard.KEY_NONE); }

    @Override
    public void onDisable() {
        // Flush all buffered packets
        if (mc.thePlayer != null) {
            for (Packet<?> p : buffer)
                mc.thePlayer.sendQueue.addToSendQueue(p);
        }
        buffer.clear();
    }

    @EventTarget
    public void onSend(EventSendPacket event) {
        buffer.add(event.getPacket());
        event.setCancelled(true);
    }
}
