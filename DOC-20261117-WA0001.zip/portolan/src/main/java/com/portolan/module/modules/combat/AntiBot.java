package com.portolan.module.modules.combat;

import com.portolan.module.Category;
import com.portolan.module.Module;
import net.minecraft.entity.player.EntityPlayer;
import org.lwjgl.input.Keyboard;

/** Flags bots — entities with invalid UUIDs or ping == 0. */
public class AntiBot extends Module {

    public AntiBot() { super("AntiBot", Category.COMBAT, "Exclude bots from target list", Keyboard.KEY_NONE); }

    public boolean isBot(EntityPlayer e) {
        if (!isEnabled()) return false;
        // No ping entry in tab list → almost certainly a bot
        if (mc.getNetHandler() == null) return false;
        return mc.getNetHandler().getPlayerInfo(e.getUniqueID()) == null;
    }
}
