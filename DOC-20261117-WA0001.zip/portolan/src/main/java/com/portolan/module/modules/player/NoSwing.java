package com.portolan.module.modules.player;

import com.portolan.event.EventTarget;
import com.portolan.event.events.EventSendPacket;
import com.portolan.module.Category;
import com.portolan.module.Module;
import net.minecraft.network.play.client.C0APacketAnimation;
import org.lwjgl.input.Keyboard;

public class NoSwing extends Module {
    public NoSwing() { super("NoSwing", Category.PLAYER, "No arm swing packet", Keyboard.KEY_NONE); }

    @EventTarget
    public void onSend(EventSendPacket event) {
        if (event.getPacket() instanceof C0APacketAnimation)
            event.setCancelled(true);
    }
}
