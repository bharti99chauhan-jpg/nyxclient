package com.portolan.module.modules.movement;

import com.portolan.event.EventTarget;
import com.portolan.event.events.EventSendPacket;
import com.portolan.module.Category;
import com.portolan.module.Module;
import net.minecraft.network.play.client.C0BPacketEntityAction;
import org.lwjgl.input.Keyboard;

public class NoSlow extends Module {

    public NoSlow() {
        super("NoSlow", Category.MOVEMENT, "No slowdown while blocking or eating", Keyboard.KEY_NONE);
    }

    @EventTarget
    public void onSendPacket(EventSendPacket event) {
        if (!(event.getPacket() instanceof C0BPacketEntityAction)) return;
        C0BPacketEntityAction p = (C0BPacketEntityAction) event.getPacket();
        // Cancel START_SNEAKING/STOP_SNEAKING and RIDING_JUMP — not the block packets
        C0BPacketEntityAction.Action a = p.getAction();
        if (a == C0BPacketEntityAction.Action.START_SNEAKING ||
            a == C0BPacketEntityAction.Action.STOP_SNEAKING) {
            event.setCancelled(true);
        }
    }
}
