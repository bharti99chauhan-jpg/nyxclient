package com.portolan.module.modules.misc;

import com.portolan.event.EventTarget;
import com.portolan.event.events.EventMotion;
import com.portolan.module.Category;
import com.portolan.module.Module;
import com.portolan.module.setting.ListSetting;
import org.lwjgl.input.Keyboard;

/** Sends packets that confuse common anticheats. */
public class Disabler extends Module {

    private final ListSetting mode = new ListSetting("Mode", "Intave", "Intave", "Polar", "Generic");

    public Disabler() {
        super("Disabler", Category.MISC, "Confuse anticheat", Keyboard.KEY_NONE);
        settings.add(mode);
    }

    @EventTarget
    public void onMotion(EventMotion event) {
        if (!event.isPre() || mc.thePlayer == null) return;

        switch (mode.getValue()) {
            case "Polar":
                // Spoof onGround true for one tick — resets Polar's flight timer
                if (!mc.thePlayer.onGround)
                    event.setOnGround(true);
                break;
            case "Intave":
            case "Generic":
                // No-op — extend as needed
                break;
        }
    }
}
