package com.portolan.module.modules.combat;

import com.portolan.module.Category;
import com.portolan.module.Module;
import com.portolan.module.setting.NumberSetting;
import org.lwjgl.input.Keyboard;

/** Exposes reach distance; MixinPlayerControllerMP reads getReach(). */
public class Reach extends Module {

    private final NumberSetting reach = new NumberSetting("Reach", 3.5, 3.0, 6.0);

    public Reach() {
        super("Reach", Category.COMBAT, "Extended attack range", Keyboard.KEY_NONE);
        settings.add(reach);
    }

    public float getReach() { return reach.floatValue(); }
}
