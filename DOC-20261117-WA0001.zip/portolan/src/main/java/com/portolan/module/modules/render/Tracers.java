package com.portolan.module.modules.render;

import com.portolan.event.EventTarget;
import com.portolan.event.events.EventRender3D;
import com.portolan.module.Category;
import com.portolan.module.Module;
import com.portolan.utils.EntityUtils;
import com.portolan.utils.RenderUtils;
import net.minecraft.entity.EntityLivingBase;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

import java.awt.*;
import java.util.List;

public class Tracers extends Module {

    public Tracers() { super("Tracers", Category.RENDER, "Draw lines to entities", Keyboard.KEY_NONE); }

    @EventTarget
    public void onRender3D(EventRender3D event) {
        if (mc.thePlayer == null || mc.theWorld == null) return;
        List<EntityLivingBase> list = EntityUtils.getNearbyLiving(64);
        for (EntityLivingBase e : list)
            RenderUtils.drawTracer(e, new Color(255, 60, 60, 200), event.getPartialTicks());
    }
}
