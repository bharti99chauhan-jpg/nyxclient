package com.portolan.module.modules.player;

import com.portolan.module.Category;
import com.portolan.module.Module;
import org.lwjgl.input.Keyboard;

/** No right-click delay — handled via MixinPlayerControllerMP. */
public class FastPlace extends Module {
    public FastPlace() { super("FastPlace", Category.PLAYER, "No block place delay", Keyboard.KEY_NONE); }
}
