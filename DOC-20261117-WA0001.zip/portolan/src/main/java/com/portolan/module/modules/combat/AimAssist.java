package com.portolan.module.modules.combat;

import com.portolan.event.EventTarget;
import com.portolan.event.events.EventMotion;
import com.portolan.module.Category;
import com.portolan.module.Module;
import com.portolan.module.setting.NumberSetting;
import com.portolan.utils.EntityUtils;
import com.portolan.utils.RotationUtils;
import net.minecraft.entity.EntityLivingBase;
import org.lwjgl.input.Keyboard;

import java.util.List;

public class AimAssist extends Module {

    private final NumberSetting range   = new NumberSetting("Range",   5.0, 1.0, 10.0);
    private final NumberSetting smooth  = new NumberSetting("Smooth",  5.0, 1.0, 20.0);
    private final NumberSetting fov     = new NumberSetting("FOV",    60.0, 1.0, 180.0);

    public AimAssist() {
        super("AimAssist", Category.COMBAT, "Soft-aimbot toward nearest player", Keyboard.KEY_NONE);
        settings.add(range); settings.add(smooth); settings.add(fov);
    }

    @EventTarget
    public void onMotion(EventMotion event) {
        if (!event.isPre() || mc.thePlayer == null) return;

        List<EntityLivingBase> nearby = EntityUtils.getNearbyLiving(range.getValue());
        if (nearby.isEmpty()) return;
        EntityLivingBase target = nearby.get(0);

        float[] ideal = RotationUtils.getBestRotation(target);
        float yaw   = RotationUtils.smoothToward(mc.thePlayer.rotationYaw,   ideal[0], 1, smooth.floatValue());
        float pitch = RotationUtils.smoothToward(mc.thePlayer.rotationPitch, ideal[1], 0.5f, smooth.floatValue() * 0.4f);

        if (RotationUtils.rotationDist(mc.thePlayer.rotationYaw, mc.thePlayer.rotationPitch, ideal[0], ideal[1]) > fov.floatValue())
            return;

        event.setYaw(yaw);
        event.setPitch(pitch);
    }
}
