package com.portolan.module.setting;

public class NumberSetting extends Setting<Double> {
    private final double min, max;

    public NumberSetting(String name, double def, double min, double max) {
        super(name, def);
        this.min = min;
        this.max = max;
    }

    @Override
    public void setValue(Double v) {
        super.setValue(Math.max(min, Math.min(max, v)));
    }

    public double getMin() { return min; }
    public double getMax() { return max; }
    public float  floatValue() { return value.floatValue(); }
    public int    intValue()   { return value.intValue(); }
}
