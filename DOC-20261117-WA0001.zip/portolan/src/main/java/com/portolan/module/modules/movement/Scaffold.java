package com.portolan.module.modules.movement;

import com.portolan.event.EventTarget;
import com.portolan.event.events.EventMotion;
import com.portolan.module.Category;
import com.portolan.module.Module;
import net.minecraft.block.Block;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.item.ItemBlock;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import org.lwjgl.input.Keyboard;

public class Scaffold extends Module {

    public Scaffold() { super("Scaffold", Category.MOVEMENT, "Auto place blocks below", Keyboard.KEY_NONE); }

    @EventTarget
    public void onMotion(EventMotion event) {
        if (!event.isPre() || mc.thePlayer == null) return;

        // Find a block item in hotbar
        int slot = findBlockSlot();
        if (slot == -1) return;

        int saved = mc.thePlayer.inventory.currentItem;
        mc.thePlayer.inventory.currentItem = slot;

        BlockPos below = new BlockPos(mc.thePlayer.posX,
                                      mc.thePlayer.posY - 1,
                                      mc.thePlayer.posZ);

        if (mc.theWorld.getBlockState(below).getBlock().getMaterial().isReplaceable()) {
            BlockPos support = below.down();
            if (!mc.theWorld.getBlockState(support).getBlock().getMaterial().isReplaceable()) {
                mc.playerController.onPlayerRightClick(mc.thePlayer,
                        mc.theWorld, mc.thePlayer.inventory.getCurrentItem(),
                        support, EnumFacing.UP, support.getX() + 0.5f, support.getY() + 1f, support.getZ() + 0.5f);
            }
        }

        mc.thePlayer.inventory.currentItem = saved;
    }

    private int findBlockSlot() {
        for (int i = 0; i < 9; i++) {
            if (mc.thePlayer.inventory.getStackInSlot(i) != null &&
                mc.thePlayer.inventory.getStackInSlot(i).getItem() instanceof ItemBlock)
                return i;
        }
        return -1;
    }
}
