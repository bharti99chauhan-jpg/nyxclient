package com.portolan.module;

public enum Category {
    COMBAT("Combat"),
    MOVEMENT("Movement"),
    PLAYER("Player"),
    RENDER("Render"),
    MISC("Misc");

    private final String display;
    Category(String d) { this.display = d; }
    public String getDisplay() { return display; }
}
