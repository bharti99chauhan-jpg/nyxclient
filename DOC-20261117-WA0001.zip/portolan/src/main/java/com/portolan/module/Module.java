package com.portolan.module;

import com.portolan.PortolanClient;
import com.portolan.module.setting.Setting;
import net.minecraft.client.Minecraft;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {

    protected static final Minecraft mc = Minecraft.getMinecraft();

    private final String   name;
    private final Category category;
    private final String   description;
    private int            key;
    private boolean        enabled = false;

    protected final List<Setting<?>> settings = new ArrayList<>();

    public Module(String name, Category category, String description, int key) {
        this.name        = name;
        this.category    = category;
        this.description = description;
        this.key         = key;
    }

    // ── lifecycle ─────────────────────────────────────────────────────────────
    public void onEnable()  {}
    public void onDisable() {}
    public void onUpdate()  {}   // called each game tick when enabled

    // ── toggle ────────────────────────────────────────────────────────────────
    public void toggle() {
        enabled = !enabled;
        if (enabled) {
            PortolanClient.eventBus.register(this);
            onEnable();
        } else {
            PortolanClient.eventBus.unregister(this);
            onDisable();
        }
    }

    public void setEnabled(boolean e) { if (e != enabled) toggle(); }

    // ── getters ───────────────────────────────────────────────────────────────
    public String   getName()        { return name; }
    public Category getCategory()    { return category; }
    public String   getDescription() { return description; }
    public int      getKey()         { return key; }
    public boolean  isEnabled()      { return enabled; }
    public List<Setting<?>> getSettings() { return settings; }

    public void setKey(int k) { this.key = k; }

    @Override
    public String toString() { return name; }
}
