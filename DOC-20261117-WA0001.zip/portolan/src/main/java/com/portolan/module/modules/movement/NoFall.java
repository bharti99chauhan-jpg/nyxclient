package com.portolan.module.modules.movement;

import com.portolan.event.EventTarget;
import com.portolan.event.events.EventMotion;
import com.portolan.module.Category;
import com.portolan.module.Module;
import org.lwjgl.input.Keyboard;

public class NoFall extends Module {
    public NoFall() { super("NoFall", Category.MOVEMENT, "No fall damage", Keyboard.KEY_NONE); }

    @EventTarget
    public void onMotion(EventMotion event) {
        if (!event.isPre() || mc.thePlayer == null) return;
        // Spoof onGround = true when falling, resets server fall distance
        if (mc.thePlayer.fallDistance > 2.5f && !mc.thePlayer.onGround) {
            event.setOnGround(true);
        }
    }
}
