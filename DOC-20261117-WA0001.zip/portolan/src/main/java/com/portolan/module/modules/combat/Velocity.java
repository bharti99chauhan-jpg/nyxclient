package com.portolan.module.modules.combat;

import com.portolan.event.EventTarget;
import com.portolan.event.events.EventSendPacket;
import com.portolan.module.Category;
import com.portolan.module.Module;
import com.portolan.module.setting.NumberSetting;
import net.minecraft.network.play.client.C0FPacketConfirmTransaction;
import net.minecraft.network.play.server.S12PacketEntityVelocity;
import org.lwjgl.input.Keyboard;

public class Velocity extends Module {

    private final NumberSetting horizontal = new NumberSetting("Horizontal", 0, 0, 100);
    private final NumberSetting vertical   = new NumberSetting("Vertical",   0, 0, 100);

    public Velocity() {
        super("Velocity", Category.COMBAT, "Reduce knockback", Keyboard.KEY_NONE);
        settings.add(horizontal);
        settings.add(vertical);
    }

    @EventTarget
    public void onSendPacket(EventSendPacket event) {
        // No velocity modification needed in send direction;
        // velocity is received in S12.  Hook is in MixinNetworkManager.
        // This module just exposes the settings; the mixin reads them.
    }

    public double getHorizontalFactor() { return horizontal.getValue() / 100.0; }
    public double getVerticalFactor()   { return vertical.getValue()   / 100.0; }
}
