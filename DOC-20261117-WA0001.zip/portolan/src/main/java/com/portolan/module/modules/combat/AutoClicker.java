package com.portolan.module.modules.combat;

import com.portolan.event.EventTarget;
import com.portolan.event.events.EventMotion;
import com.portolan.module.Category;
import com.portolan.module.Module;
import com.portolan.module.setting.NumberSetting;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import java.util.Random;

public class AutoClicker extends Module {

    private final NumberSetting minCps = new NumberSetting("MinCPS", 10, 1, 20);
    private final NumberSetting maxCps = new NumberSetting("MaxCPS", 14, 1, 20);

    private final Random rng = new Random();
    private long nextClick   = 0;

    public AutoClicker() {
        super("AutoClicker", Category.COMBAT, "Auto left click", Keyboard.KEY_NONE);
        settings.add(minCps); settings.add(maxCps);
    }

    @EventTarget
    public void onMotion(EventMotion event) {
        if (!event.isPre() || mc.thePlayer == null) return;
        if (!Mouse.isButtonDown(0)) return;

        long now = System.currentTimeMillis();
        if (now < nextClick) return;

        // randomised interval between minCps and maxCps
        double cps      = minCps.getValue() + rng.nextDouble() * (maxCps.getValue() - minCps.getValue());
        long   interval = (long)(1000.0 / cps);
        nextClick = now + interval;

        if (mc.objectMouseOver != null && mc.objectMouseOver.entityHit != null) {
            mc.playerController.attackEntity(mc.thePlayer, mc.objectMouseOver.entityHit);
            mc.thePlayer.swingItem();
        }
    }
}
