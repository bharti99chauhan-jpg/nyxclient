package com.portolan.module.modules.player;

import com.portolan.module.Category;
import com.portolan.module.Module;
import org.lwjgl.input.Keyboard;

/** Faster eating — handled via MixinEntityPlayerSP itemUsePeriod override. */
public class FastEat extends Module {
    public FastEat() { super("FastEat", Category.PLAYER, "Eat faster", Keyboard.KEY_NONE); }
}
