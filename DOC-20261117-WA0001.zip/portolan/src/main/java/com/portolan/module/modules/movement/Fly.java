package com.portolan.module.modules.movement;

import com.portolan.event.EventTarget;
import com.portolan.event.events.EventMotion;
import com.portolan.module.Category;
import com.portolan.module.Module;
import com.portolan.module.setting.ListSetting;
import com.portolan.module.setting.NumberSetting;
import com.portolan.utils.MovementUtils;
import org.lwjgl.input.Keyboard;

public class Fly extends Module {

    private final ListSetting   mode  = new ListSetting("Mode", "Vanilla", "Vanilla", "Creative");
    private final NumberSetting speed = new NumberSetting("Speed", 0.9, 0.1, 10.0);

    public Fly() {
        super("Fly", Category.MOVEMENT, "Fly", Keyboard.KEY_NONE);
        settings.add(mode);
        settings.add(speed);
    }

    @Override
    public void onEnable() {
        if (mc.thePlayer != null) {
            mc.thePlayer.capabilities.allowFlying = true;
            mc.thePlayer.capabilities.isFlying    = true;
        }
    }

    @Override
    public void onDisable() {
        if (mc.thePlayer != null && !mc.thePlayer.capabilities.isCreativeMode) {
            mc.thePlayer.capabilities.allowFlying = false;
            mc.thePlayer.capabilities.isFlying    = false;
        }
    }

    @EventTarget
    public void onMotion(EventMotion event) {
        if (!event.isPre() || mc.thePlayer == null) return;

        if (mode.is("Vanilla")) {
            mc.thePlayer.capabilities.flySpeed = speed.floatValue() * 0.05f;
            mc.thePlayer.capabilities.allowFlying = true;
            mc.thePlayer.capabilities.isFlying    = true;
        } else {
            MovementUtils.setMotion(mc.thePlayer, speed.getValue());
            mc.thePlayer.motionY = 0;
            if (mc.gameSettings.keyBindJump.isKeyDown())    mc.thePlayer.motionY =  speed.getValue();
            if (mc.gameSettings.keyBindSneak.isKeyDown())   mc.thePlayer.motionY = -speed.getValue();
        }
    }
}
