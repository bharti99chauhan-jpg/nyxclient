package com.portolan.module.modules.movement;

import com.portolan.event.EventTarget;
import com.portolan.event.events.EventMotion;
import com.portolan.module.Category;
import com.portolan.module.Module;
import com.portolan.utils.MovementUtils;
import org.lwjgl.input.Keyboard;

public class Sprint extends Module {
    public Sprint() { super("Sprint", Category.MOVEMENT, "Auto sprint", Keyboard.KEY_NONE); }

    @EventTarget
    public void onMotion(EventMotion event) {
        if (!event.isPre() || mc.thePlayer == null) return;
        if (MovementUtils.isMoving() && mc.thePlayer.getFoodStats().getFoodLevel() > 6)
            mc.thePlayer.setSprinting(true);
    }
}
