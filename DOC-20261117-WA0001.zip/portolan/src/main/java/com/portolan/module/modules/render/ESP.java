package com.portolan.module.modules.render;

import com.portolan.event.EventTarget;
import com.portolan.event.events.EventRender3D;
import com.portolan.module.Category;
import com.portolan.module.Module;
import com.portolan.module.setting.ListSetting;
import com.portolan.utils.EntityUtils;
import com.portolan.utils.RenderUtils;
import net.minecraft.entity.EntityLivingBase;
import org.lwjgl.input.Keyboard;

import java.awt.*;
import java.util.List;

public class ESP extends Module {

    private final ListSetting mode = new ListSetting("Mode", "Box", "Box", "Health");

    public ESP() {
        super("ESP", Category.RENDER, "Highlight entities through walls", Keyboard.KEY_NONE);
        settings.add(mode);
    }

    @EventTarget
    public void onRender3D(EventRender3D event) {
        if (mc.thePlayer == null || mc.theWorld == null) return;
        List<EntityLivingBase> list = EntityUtils.getNearbyLiving(64);
        for (EntityLivingBase e : list)
            RenderUtils.drawEntityBox(e, new Color(255, 60, 60, 160), event.getPartialTicks());
    }
}
