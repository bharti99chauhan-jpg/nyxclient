package com.portolan.module.modules.combat;

import com.portolan.PortolanClient;
import com.portolan.event.EventTarget;
import com.portolan.event.events.EventMotion;
import com.portolan.module.Category;
import com.portolan.module.Module;
import com.portolan.module.setting.BoolSetting;
import com.portolan.module.setting.ListSetting;
import com.portolan.module.setting.NumberSetting;
import com.portolan.utils.EntityUtils;
import com.portolan.utils.RotationUtils;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import org.lwjgl.input.Keyboard;

import java.util.List;

/**
 * KillAura — server-side rotations, Polar-bypass.
 *
 * Rotation pipeline:
 *   PRE event  → compute server rotation (smooth, GCD-snapped)
 *                set event yaw/pitch  → goes into C03 packet
 *                set all player rotation fields so the attack lands correctly
 *   Attack     → mc.playerController.attackEntity() inside PRE, after fields are set
 *   POST event → restore all player rotation fields to saved client values
 *
 * This keeps the RENDER at the client yaw/pitch (player sees their own view)
 * while the SERVER receives the correct aimed rotation in every C03 packet.
 *
 * Polar FOV gate:  attack is only sent when rotationDist(server, target) < attackFov.
 * This prevents Polar flagging attacks that arrive with a rotation that couldn't
 * realistically have hit the entity.
 */
public class KillAura extends Module {

    // ── Settings ─────────────────────────────────────────────────────────────
    private final NumberSetting range       = new NumberSetting("Range",     3.0, 1.0, 6.0);
    private final NumberSetting cps         = new NumberSetting("CPS",       10,  1,   20);
    private final NumberSetting minStep     = new NumberSetting("MinStep",   5,   1,   30);
    private final NumberSetting maxStep     = new NumberSetting("MaxStep",   15,  5,   90);
    private final ListSetting   targetMode  = new ListSetting("Target",  "Players", "Players", "Mobs", "All");
    private final BoolSetting   throughWall = new BoolSetting("ThroughWalls", false);
    private final BoolSetting   sprint      = new BoolSetting("Sprint",        true);
    private final NumberSetting attackFov   = new NumberSetting("AttackFOV",  90, 1, 180);

    // ── State ─────────────────────────────────────────────────────────────────
    /** Smooth-state: persists server yaw/pitch across ticks for the smooth step. */
    private final float[] smoothState = new float[2];

    /** Saved client rotations — restored in POST. */
    private float savedYaw, savedPitch;

    /** Whether we modified rotations this tick (need restore in POST). */
    private boolean rotationActive = false;

    /** Current target. */
    private EntityLivingBase target = null;

    /** True if attack should fire this tick (set in PRE, consumed in PRE). */
    private boolean shouldAttackThisTick = false;

    /** Set to true in PRE so AutoBlock knows to block this tick. */
    public  boolean attackingThisTick = false;

    private long lastAttackMs = 0;

    public KillAura() {
        super("KillAura", Category.COMBAT, "Attacks nearby entities automatically", Keyboard.KEY_R);
        settings.add(range);
        settings.add(cps);
        settings.add(minStep);
        settings.add(maxStep);
        settings.add(targetMode);
        settings.add(throughWall);
        settings.add(sprint);
        settings.add(attackFov);
    }

    @Override
    public void onEnable() {
        // Seed smooth state to current view so the first step doesn't jump
        if (mc.thePlayer != null) {
            smoothState[0] = mc.thePlayer.rotationYaw;
            smoothState[1] = mc.thePlayer.rotationPitch;
        }
        rotationActive    = false;
        attackingThisTick = false;
        target            = null;
    }

    @Override
    public void onDisable() {
        // If we're mid-tick disable, make sure client rotations are restored
        if (rotationActive && mc.thePlayer != null) {
            restoreRotations();
        }
        rotationActive    = false;
        attackingThisTick = false;
        target            = null;
    }

    // ── PRE motion ───────────────────────────────────────────────────────────

    @EventTarget
    public void onMotionPre(EventMotion event) {
        if (!event.isPre()) return;
        attackingThisTick = false;
        shouldAttackThisTick = false;

        if (mc.thePlayer == null || mc.theWorld == null) return;

        // Pick target
        target = findTarget();
        if (target == null) return;

        // Compute ideal rotation toward best point on target AABB
        float[] ideal = RotationUtils.getBestRotation(target,
                smoothState[0], smoothState[1]);

        // Smooth-step toward ideal, GCD-snapped
        float[] server = RotationUtils.stepServerRotation(
                ideal[0], ideal[1],
                smoothState,
                minStep.floatValue(),
                maxStep.floatValue());

        // Save client rotations for restoration in POST
        savedYaw   = mc.thePlayer.rotationYaw;
        savedPitch = mc.thePlayer.rotationPitch;
        rotationActive = true;

        // ── Set C03 packet rotation ──────────────────────────────────────────
        event.setYaw(server[0]);
        event.setPitch(server[1]);

        // ── Set ALL player rotation fields ───────────────────────────────────
        // Polar checks head/body tracking against the sent C03 yaw.
        // prevRotationYaw affects the attack direction calculation server-side.
        // renderYawOffset / rotationYawHead are compared against the last sent yaw
        // to detect head/body desync.
        mc.thePlayer.rotationYaw        = server[0];
        mc.thePlayer.rotationPitch      = server[1];
        mc.thePlayer.prevRotationYaw    = server[0];
        mc.thePlayer.prevRotationPitch  = server[1];
        mc.thePlayer.renderYawOffset    = server[0];
        mc.thePlayer.prevRenderYawOffset= server[0];
        mc.thePlayer.rotationYawHead    = server[0];

        // ── Gate attack on FOV ───────────────────────────────────────────────
        // Only attack when server rotation is actually close enough to the target.
        // Prevents Polar seeing an attack arrive that the rotation couldn't have aimed.
        boolean inFov = RotationUtils.canSee(target,
                server[0], server[1], attackFov.floatValue());

        // ── CPS gate ─────────────────────────────────────────────────────────
        long now = System.currentTimeMillis();
        double interval = 1000.0 / cps.getValue();
        boolean cpsReady = (now - lastAttackMs) >= interval;

        if (inFov && cpsReady) {
            shouldAttackThisTick = true;
            attackingThisTick    = true;
        }

        // ── Sprint ───────────────────────────────────────────────────────────
        if (sprint.isEnabled() && mc.thePlayer.getFoodStats().getFoodLevel() > 6) {
            mc.thePlayer.setSprinting(true);
        }

        // ── Fire attack ──────────────────────────────────────────────────────
        // Attack happens here, after all rotation fields are set, so the swing
        // animation and the server-side hitbox check both use the server rotation.
        if (shouldAttackThisTick) {
            mc.playerController.attackEntity(mc.thePlayer, target);
            mc.thePlayer.swingItem();
            lastAttackMs = now;
        }
    }

    // ── POST motion ──────────────────────────────────────────────────────────

    @EventTarget
    public void onMotionPost(EventMotion event) {
        if (!event.isPost()) return;
        if (!rotationActive) return;

        // Restore all rotation fields to client values — rendering stays at the
        // player's actual view direction, server received the aimed rotation.
        restoreRotations();
        rotationActive = false;
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private void restoreRotations() {
        event_setYawPitch(savedYaw, savedPitch);
    }

    /**
     * Write all rotation fields back to the given values.
     * Called with server values in PRE (after packet is built), client values in POST.
     */
    private void event_setYawPitch(float yaw, float pitch) {
        mc.thePlayer.rotationYaw         = yaw;
        mc.thePlayer.rotationPitch       = pitch;
        mc.thePlayer.prevRotationYaw     = yaw;
        mc.thePlayer.prevRotationPitch   = pitch;
        mc.thePlayer.renderYawOffset     = yaw;
        mc.thePlayer.prevRenderYawOffset = yaw;
        mc.thePlayer.rotationYawHead     = yaw;
    }

    private EntityLivingBase findTarget() {
        double r = range.getValue();
        List<EntityLivingBase> nearby = EntityUtils.getNearbyLiving(r);
        for (EntityLivingBase e : nearby) {
            if (!passesFilter(e)) continue;
            if (!throughWall.isEnabled() && !EntityUtils.canSee(e)) continue;
            return e;   // sorted by distance, so first valid = closest
        }
        return null;
    }

    private boolean passesFilter(EntityLivingBase e) {
        if (e == mc.thePlayer) return false;
        switch (targetMode.getValue()) {
            case "Players": return e instanceof EntityPlayer;
            case "Mobs":    return EntityUtils.isMob(e);
            case "All":     return true;
            default:        return false;
        }
    }

    public EntityLivingBase getTarget() { return target; }
}
