package com.portolan.module.modules.movement;

import com.portolan.event.EventTarget;
import com.portolan.event.events.EventMotion;
import com.portolan.module.Category;
import com.portolan.module.Module;
import com.portolan.module.setting.NumberSetting;
import com.portolan.utils.MovementUtils;
import org.lwjgl.input.Keyboard;

/**
 * BHop — jump every ground frame, scale air speed post-physics.
 * No horizontal velocity injection on the jump tick itself.
 */
public class BHop extends Module {

    private final NumberSetting boost = new NumberSetting("AirBoost", 1.015, 1.0, 1.1);

    public BHop() {
        super("BHop", Category.MOVEMENT, "Bunny-hop", Keyboard.KEY_NONE);
        settings.add(boost);
    }

    @EventTarget
    public void onMotion(EventMotion event) {
        if (mc.thePlayer == null) return;
        if (!MovementUtils.isMoving()) return;

        // PRE: jump on ground
        if (event.isPre() && mc.thePlayer.onGround) {
            mc.thePlayer.jump();
            return;
        }

        // POST, airborne: mild multiplicative boost each tick
        // 1.015 compounds to ~0.33 b/t after 10 ticks vs vanilla 0.20 b/t
        // Keep below 1.03 — above that Polar flags acceleration derivative
        if (event.isPost() && !mc.thePlayer.onGround) {
            mc.thePlayer.motionX *= boost.getValue();
            mc.thePlayer.motionZ *= boost.getValue();
        }
    }
}
