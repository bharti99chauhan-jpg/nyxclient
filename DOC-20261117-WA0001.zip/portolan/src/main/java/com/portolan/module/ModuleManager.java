package com.portolan.module;

import com.portolan.module.modules.combat.*;
import com.portolan.module.modules.misc.*;
import com.portolan.module.modules.movement.*;
import com.portolan.module.modules.player.*;
import com.portolan.module.modules.render.*;
import org.lwjgl.input.Keyboard;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class ModuleManager {

    private final List<Module> modules = new ArrayList<>();

    public ModuleManager() {
        // Combat
        add(new KillAura());
        add(new AutoBlock());
        add(new AimAssist());
        add(new Velocity());
        add(new Criticals());
        add(new Reach());
        add(new AntiBot());
        add(new AutoClicker());
        // Movement
        add(new Speed());
        add(new BHop());
        add(new Fly());
        add(new NoSlow());
        add(new Sprint());
        add(new NoFall());
        add(new Scaffold());
        add(new SafeWalk());
        // Player
        add(new FastEat());
        add(new FastPlace());
        add(new NoSwing());
        // Render
        add(new ESP());
        add(new ArmorHUD());
        add(new FullBright());
        add(new Tracers());
        // Misc
        add(new Disabler());
        add(new Timer());
        add(new AntiAFK());
        add(new Blink());
    }

    private void add(Module m) { modules.add(m); }

    public void onKey(int key) {
        if (key == Keyboard.KEY_NONE) return;
        for (Module m : modules)
            if (m.getKey() == key) m.toggle();
    }

    public List<Module> getAll()                    { return modules; }
    public List<Module> byCategory(Category cat)    { return modules.stream().filter(m -> m.getCategory() == cat).collect(Collectors.toList()); }

    @SuppressWarnings("unchecked")
    public <T extends Module> T get(Class<T> cls) {
        for (Module m : modules)
            if (cls.isInstance(m)) return (T) m;
        return null;
    }

    public Module get(String name) {
        for (Module m : modules)
            if (m.getName().equalsIgnoreCase(name)) return m;
        return null;
    }

    public boolean isEnabled(Class<? extends Module> cls) {
        Module m = get(cls);
        return m != null && m.isEnabled();
    }
}
