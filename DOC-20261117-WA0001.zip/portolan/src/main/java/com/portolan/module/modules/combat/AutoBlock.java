package com.portolan.module.modules.combat;

import com.portolan.PortolanClient;
import com.portolan.event.EventTarget;
import com.portolan.event.events.EventMotion;
import com.portolan.module.Category;
import com.portolan.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.util.BlockPos;
import org.lwjgl.input.Keyboard;

/**
 * AutoBlock — Polar-safe.
 *
 * The original client sent C08 with BlockPos.ORIGIN + facing 255 on EVERY PRE tick,
 * regardless of whether KillAura was attacking.  Polar flags the constant packet rhythm.
 *
 * Fix:  only send the block packet on the tick KillAura fires an attack.
 * The sequence per attacking tick is:
 *   PRE  → send C08 (START block state on server)
 *   KA fires attack packet
 *   POST → send C08 again (server-side this functions as an END, returning to idle)
 *
 * On non-attacking ticks: no block packets at all.
 * This eliminates the fixed-interval signature while still showing the block animation.
 */
public class AutoBlock extends Module {

    // Shared reference to KillAura — read its attackingThisTick flag
    private KillAura ka;

    public AutoBlock() {
        super("AutoBlock", Category.COMBAT, "Blocks only on attack ticks", Keyboard.KEY_NONE);
    }

    @Override
    public void onEnable() {
        ka = PortolanClient.moduleManager.get(KillAura.class);
    }

    @Override
    public void onDisable() {
        // Ensure we're not stuck in block state
        stopBlock();
        ka = null;
    }

    @EventTarget
    public void onMotionPre(EventMotion event) {
        if (!event.isPre()) return;
        if (ka == null || !ka.isEnabled()) return;

        // Only block on the tick KillAura is attacking
        if (ka.attackingThisTick) {
            startBlock();
        }
    }

    @EventTarget
    public void onMotionPost(EventMotion event) {
        if (!event.isPost()) return;
        if (ka == null || !ka.isEnabled()) return;

        // Drop block after the attack packet has been sent
        if (ka.attackingThisTick) {
            stopBlock();
        }
    }

    // ── C08 helpers ──────────────────────────────────────────────────────────

    private static void startBlock() {
        sendBlock();
    }

    private static void stopBlock() {
        sendBlock();
    }

    /**
     * C08PacketPlayerBlockPlacement with facing 255 and ORIGIN position is the
     * standard 1.8 "start blocking" signal.  Sending it twice (start + stop) in
     * the same tick is safe — the server processes them in order.
     */
    private static void sendBlock() {
        if (Minecraft.getMinecraft().thePlayer == null) return;
        Minecraft.getMinecraft().thePlayer.sendQueue.addToSendQueue(
            new C08PacketPlayerBlockPlacement(
                BlockPos.ORIGIN,
                255,
                Minecraft.getMinecraft().thePlayer.inventory.getCurrentItem(),
                0f, 0f, 0f
            )
        );
    }
}
