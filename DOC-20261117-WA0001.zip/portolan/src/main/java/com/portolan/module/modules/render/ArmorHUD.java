package com.portolan.module.modules.render;

import com.portolan.event.EventTarget;
import com.portolan.event.events.EventRender2D;
import com.portolan.module.Category;
import com.portolan.module.Module;
import net.minecraft.client.gui.Gui;
import net.minecraft.item.ItemStack;
import org.lwjgl.input.Keyboard;

public class ArmorHUD extends Module {

    public ArmorHUD() { super("ArmorHUD", Category.RENDER, "Show armor durability", Keyboard.KEY_NONE); }

    @EventTarget
    public void onRender2D(EventRender2D event) {
        if (mc.thePlayer == null) return;
        int x = 2, y = mc.displayHeight / 2 - 40;
        for (int i = 3; i >= 0; i--) {
            ItemStack stack = mc.thePlayer.inventory.armorInventory[i];
            if (stack == null) continue;
            mc.getRenderItem().renderItemIntoGUI(stack, x, y);
            if (stack.isItemStackDamageable()) {
                int dur = stack.getMaxDamage() - stack.getItemDamage();
                mc.fontRendererObj.drawStringWithShadow(String.valueOf(dur), x + 18, y + 6, 0xFFFFFF);
            }
            y += 18;
        }
    }
}
