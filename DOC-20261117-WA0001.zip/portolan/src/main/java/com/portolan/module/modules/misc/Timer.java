package com.portolan.module.modules.misc;

import com.portolan.module.Category;
import com.portolan.module.Module;
import com.portolan.module.setting.NumberSetting;
import org.lwjgl.input.Keyboard;

/** Game timer multiplier — read by MixinMinecraft. */
public class Timer extends Module {

    private final NumberSetting speed = new NumberSetting("Speed", 1.0, 0.1, 10.0);

    public Timer() {
        super("Timer", Category.MISC, "Speed up game timer", Keyboard.KEY_NONE);
        settings.add(speed);
    }

    public float getSpeed() { return speed.floatValue(); }
}
