package com.portolan.module.modules.combat;

import com.portolan.event.EventTarget;
import com.portolan.event.events.EventMotion;
import com.portolan.module.Category;
import com.portolan.module.Module;
import org.lwjgl.input.Keyboard;

public class Criticals extends Module {

    public Criticals() { super("Criticals", Category.COMBAT, "Always crit", Keyboard.KEY_NONE); }

    @EventTarget
    public void onMotion(EventMotion event) {
        if (!event.isPre() || mc.thePlayer == null) return;
        if (mc.thePlayer.onGround && mc.thePlayer.fallDistance == 0) {
            // Micro-hop: set tiny upward velocity so the next attack is airborne
            mc.thePlayer.motionY = 0.0625;
        }
    }
}
