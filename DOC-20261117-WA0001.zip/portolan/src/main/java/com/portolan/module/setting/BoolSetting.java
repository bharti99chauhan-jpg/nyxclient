package com.portolan.module.setting;

public class BoolSetting extends Setting<Boolean> {
    public BoolSetting(String name, boolean def) { super(name, def); }
    public boolean isEnabled() { return value; }
    public void toggle() { value = !value; }
}
