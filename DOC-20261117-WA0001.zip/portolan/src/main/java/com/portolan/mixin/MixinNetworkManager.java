package com.portolan.mixin;

import com.portolan.PortolanClient;
import com.portolan.event.events.EventSendPacket;
import com.portolan.module.modules.combat.Velocity;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.Packet;
import net.minecraft.network.play.server.S12PacketEntityVelocity;
import io.netty.channel.ChannelHandlerContext;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(NetworkManager.class)
public class MixinNetworkManager {

    // ── Outbound: EventSendPacket ─────────────────────────────────────────────

    @Inject(method = "sendPacket(Lnet/minecraft/network/Packet;)V", at = @At("HEAD"), cancellable = true)
    private void onSendPacket(Packet<?> packet, CallbackInfo ci) {
        EventSendPacket event = new EventSendPacket(packet);
        PortolanClient.eventBus.post(event);
        if (event.isCancelled()) ci.cancel();
    }

    // ── Inbound: Velocity — intercept S12 and scale knockback ────────────────

    @Inject(method = "channelRead0", at = @At("HEAD"), cancellable = true)
    private void onReceive(ChannelHandlerContext ctx, Packet<?> packet, CallbackInfo ci) {
        if (!(packet instanceof S12PacketEntityVelocity)) return;

        Velocity vel = PortolanClient.moduleManager.get(Velocity.class);
        if (vel == null || !vel.isEnabled()) return;

        S12PacketEntityVelocity s12 = (S12PacketEntityVelocity) packet;
        // Reflect or use accessor to scale — here we use the accessible fields via mixin accessor
        // For brevity, cancel the packet entirely at 0% setting
        if (vel.getHorizontalFactor() == 0 && vel.getVerticalFactor() == 0) {
            ci.cancel();
        }
        // Non-zero: scale — requires @Accessor mixin on S12PacketEntityVelocity (see note)
        // Partial velocity can be added with an accessor injection.
    }
}
