package com.portolan.mixin;

import com.portolan.PortolanClient;
import com.portolan.event.events.EventKey;
import com.portolan.event.events.EventRender2D;
import com.portolan.event.events.EventRender3D;
import com.portolan.module.modules.misc.Timer;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Timer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Minecraft.class)
public class MixinMinecraft {

    @Shadow private net.minecraft.util.Timer timer;

    // ── Timer ─────────────────────────────────────────────────────────────────

    @Inject(method = "runGameLoop", at = @At("HEAD"))
    private void injectTimer(CallbackInfo ci) {
        com.portolan.module.modules.misc.Timer timerModule =
            PortolanClient.moduleManager.get(com.portolan.module.modules.misc.Timer.class);

        if (timerModule != null && timerModule.isEnabled()) {
            timer.timerSpeed = timerModule.getSpeed();
        } else {
            timer.timerSpeed = 1.0f;
        }
    }

    // ── Render 2D ─────────────────────────────────────────────────────────────

    @Inject(method = "ingameHud$renderGameOverlay",
            at = @At("RETURN"),
            remap = false)
    private void onRender2D(float partialTicks, CallbackInfo ci) {
        PortolanClient.eventBus.post(new EventRender2D(partialTicks));
    }

    // ── Render 3D ─────────────────────────────────────────────────────────────

    @Inject(method = "renderWorld", at = @At("RETURN"))
    private void onRender3D(float partialTicks, long finishTimeNano, CallbackInfo ci) {
        PortolanClient.eventBus.post(new EventRender3D(partialTicks));
    }

    // ── Key input ─────────────────────────────────────────────────────────────

    @Inject(method = "dispatchKeypresses", at = @At("HEAD"))
    private void onKey(CallbackInfo ci) {
        // Key dispatch happens in runTick; we hook the dispatch loop via
        // the runTick injection — handled in runTick below.
    }

    @Inject(method = "runTick", at = @At("HEAD"))
    private void onTick(CallbackInfo ci) {
        // Poll keyboard for module hotkeys
        org.lwjgl.input.Keyboard.enableRepeatEvents(false);
        while (org.lwjgl.input.Keyboard.next()) {
            if (!org.lwjgl.input.Keyboard.getEventKeyState()) continue;
            int key = org.lwjgl.input.Keyboard.getEventKey();
            PortolanClient.moduleManager.onKey(key);
            PortolanClient.eventBus.post(new EventKey(key));
        }
    }
}
