package com.portolan.mixin;

import com.portolan.PortolanClient;
import com.portolan.event.events.EventMotion;
import com.portolan.module.modules.player.FastEat;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.potion.Potion;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(EntityPlayerSP.class)
public abstract class MixinEntityPlayerSP {

    // ── Shadowed rotation fields ──────────────────────────────────────────────
    @Shadow public float rotationYaw;
    @Shadow public float rotationPitch;
    @Shadow public float prevRotationYaw;
    @Shadow public float prevRotationPitch;
    @Shadow public float renderYawOffset;
    @Shadow public float prevRenderYawOffset;
    @Shadow public float rotationYawHead;

    // ── onUpdateWalkingPlayer — fires PRE then POST motion events ─────────────

    @Inject(method = "onUpdateWalkingPlayer", at = @At("HEAD"))
    private void motionPre(CallbackInfo ci) {
        EntityPlayerSP self = (EntityPlayerSP)(Object)this;

        EventMotion event = new EventMotion(
            EventMotion.State.PRE,
            rotationYaw, rotationPitch,
            self.posX, self.posY, self.posZ,
            self.onGround
        );

        PortolanClient.eventBus.post(event);

        // ── Apply rotation to ALL fields before the C03 packet is built ───────
        // Polar checks head/body tracking against the sent yaw.
        // Setting only rotationYaw leaves renderYawOffset / prevRotationYaw
        // out of sync, which Polar flags as a desync.
        if (event.isRotationModified()) {
            setAllRotationFields(event.getYaw(), event.getPitch());
        }

        // ── Ground spoof for NoFall / Disabler ────────────────────────────────
        if (event.isOnGroundModified()) {
            self.onGround = event.isOnGround();
        }

        // ── Position override (future use) ────────────────────────────────────
        self.posX = event.getX();
        self.posY = event.getY();
        self.posZ = event.getZ();
    }

    @Inject(method = "onUpdateWalkingPlayer", at = @At("RETURN"))
    private void motionPost(CallbackInfo ci) {
        EntityPlayerSP self = (EntityPlayerSP)(Object)this;

        EventMotion event = new EventMotion(
            EventMotion.State.POST,
            rotationYaw, rotationPitch,
            self.posX, self.posY, self.posZ,
            self.onGround
        );

        PortolanClient.eventBus.post(event);

        // POST: KillAura's handler restores clientYaw/Pitch by calling event.setYaw/setPitch
        // Those values arrive back here — apply them.
        if (event.isRotationModified()) {
            setAllRotationFields(event.getYaw(), event.getPitch());
        }
    }

    // ── FastEat — override item use period ───────────────────────────────────

    @Inject(method = "getItemInUseCount", at = @At("RETURN"), cancellable = true)
    private void fastEat(CallbackInfoReturnable<Integer> cir) {
        if (PortolanClient.moduleManager.isEnabled(FastEat.class)) {
            // Vanilla returns 32 at start of eating; we return 25 → faster finish
            if (cir.getReturnValue() > 25) cir.setReturnValue(25);
        }
    }

    // ── Helper: set every rotation field at once ──────────────────────────────

    private void setAllRotationFields(float yaw, float pitch) {
        rotationYaw         = yaw;
        rotationPitch       = pitch;
        prevRotationYaw     = yaw;
        prevRotationPitch   = pitch;
        renderYawOffset     = yaw;
        prevRenderYawOffset = yaw;
        rotationYawHead     = yaw;
    }
}
