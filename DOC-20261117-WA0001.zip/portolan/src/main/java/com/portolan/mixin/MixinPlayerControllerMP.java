package com.portolan.mixin;

import com.portolan.PortolanClient;
import com.portolan.module.modules.combat.Reach;
import com.portolan.module.modules.player.FastPlace;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PlayerControllerMP.class)
public abstract class MixinPlayerControllerMP {

    @Shadow private int blockHitDelay;

    // ── Reach — override the reach-distance check in attackEntity ─────────────
    //
    // getBlockReachDistance() is used for block interaction.
    // The entity attack reach is checked in Minecraft.clickMouse() against
    // mc.playerController.extendedReach / getBlockReachDistance.
    // We redirect the getBlockReachDistance call that guards the attack.

    @Inject(method = "getBlockReachDistance", at = @At("RETURN"), cancellable = true)
    private void injectReach(CallbackInfoReturnable<Float> cir) {
        Reach reachModule = PortolanClient.moduleManager.get(Reach.class);
        if (reachModule != null && reachModule.isEnabled()) {
            cir.setReturnValue(reachModule.getReach());
        }
    }

    // ── FastPlace — zero out the right-click delay ────────────────────────────
    //
    // blockHitDelay counts down 4 ticks between right-click uses.
    // We set it to 0 every tick when FastPlace is on.

    @Inject(method = "updateController", at = @At("RETURN"))
    private void injectFastPlace(org.spongepowered.asm.mixin.injection.callback.CallbackInfo ci) {
        FastPlace fp = PortolanClient.moduleManager.get(FastPlace.class);
        if (fp != null && fp.isEnabled()) {
            blockHitDelay = 0;
        }
    }
}
