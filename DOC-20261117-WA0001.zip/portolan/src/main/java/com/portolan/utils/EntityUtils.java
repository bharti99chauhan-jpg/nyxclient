package com.portolan.utils;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.Vec3;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public final class EntityUtils {

    private static final Minecraft mc = Minecraft.getMinecraft();

    private EntityUtils() {}

    public static boolean isValid(Entity e) {
        if (e == null) return false;
        if (e == mc.thePlayer) return false;
        if (!e.isEntityAlive()) return false;
        return true;
    }

    public static boolean isPlayer(Entity e) {
        return e instanceof EntityPlayer && isValid(e);
    }

    public static boolean isMob(Entity e) {
        return e instanceof EntityMob && isValid(e);
    }

    public static boolean isAnimal(Entity e) {
        return e instanceof EntityAnimal && isValid(e);
    }

    public static boolean isLiving(Entity e) {
        return e instanceof EntityLivingBase && isValid(e);
    }

    public static double distanceTo(Entity e) {
        return mc.thePlayer.getDistanceToEntity(e);
    }

    /** Raytrace from player eye to entity — true if no block in between. */
    public static boolean canSee(Entity e) {
        Vec3 eyes = mc.thePlayer.getPositionEyes(1f);
        Vec3 look = e.getPositionEyes(1f);
        return mc.theWorld.rayTraceBlocks(eyes, look) == null;
    }

    /** Sorted by distance ascending. */
    public static List<EntityLivingBase> getNearbyLiving(double range) {
        List<EntityLivingBase> list = new ArrayList<>();
        for (Entity e : mc.theWorld.loadedEntityList) {
            if (!(e instanceof EntityLivingBase)) continue;
            if (!isValid(e)) continue;
            if (distanceTo(e) <= range) list.add((EntityLivingBase) e);
        }
        list.sort(Comparator.comparingDouble(EntityUtils::distanceTo));
        return list;
    }

    public static List<EntityPlayer> getNearbyPlayers(double range) {
        List<EntityPlayer> list = new ArrayList<>();
        for (Entity e : mc.theWorld.loadedEntityList) {
            if (!isPlayer(e)) continue;
            if (distanceTo(e) <= range) list.add((EntityPlayer) e);
        }
        list.sort(Comparator.comparingDouble(EntityUtils::distanceTo));
        return list;
    }
}
