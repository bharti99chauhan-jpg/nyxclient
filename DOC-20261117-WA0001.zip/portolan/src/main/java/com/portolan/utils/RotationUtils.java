package com.portolan.utils;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.MathHelper;

import java.util.Random;

/**
 * Rotation math + Polar bypass.
 *
 * Polar checks (1.8 / 1.9 builds):
 *   - GCD consistency: every delta must be a multiple of (sens*0.6+0.2)^3*8
 *   - Acceleration: single-tick jumps > ~90° are flagged independently of GCD
 *   - Cinematic: extremely smooth constant-radius arcs also flagged (they look scripted)
 *   - Head/body desync: renderYawOffset / rotationYawHead must track the sent yaw
 *
 * Fix for each:
 *   GCD     → snapToGCD() on every delta before it goes into the C03 packet
 *   Accel   → smoothToward() with a per-tick cap; randomised slightly so no constant rate
 *   Cinematic → gaussian jitter on the step size keeps the arc organic
 *   Desync  → MixinEntityPlayerSP writes ALL rotation fields before the packet is built,
 *              restores them after (see KillAura PRE/POST handlers)
 */
public final class RotationUtils {

    private static final Minecraft mc  = Minecraft.getMinecraft();
    private static final Random    rng = new Random();

    private RotationUtils() {}

    // ── GCD ──────────────────────────────────────────────────────────────────

    /** Mouse-sensitivity GCD Polar checks every delta against. */
    public static double getGCD() {
        double sens = mc.gameSettings.mouseSensitivity;
        double f    = sens * 0.6 + 0.2;
        return f * f * f * 8.0;
    }

    /** Snap a rotation delta to the nearest GCD multiple. */
    public static float snapToGCD(float delta) {
        double gcd = getGCD();
        if (gcd < 0.001) return delta;
        return (float) (Math.round(delta / gcd) * gcd);
    }

    // ── Smooth step ──────────────────────────────────────────────────────────

    /**
     * Move {@code current} toward {@code target} by at most {@code maxStep},
     * with a small gaussian jitter on the step size so the arc is not constant-radius.
     * The resulting delta is GCD-snapped before returning.
     *
     * @param minStep minimum degrees per tick (e.g. 3)
     * @param maxStep maximum degrees per tick (e.g. 15 for legit feel)
     */
    public static float smoothToward(float current, float target, float minStep, float maxStep) {
        float diff = angleDiff(current, target);
        if (Math.abs(diff) < 0.001f) return target;

        // Gaussian jitter on step size — avoids constant-radius flag
        float sigma = (maxStep - minStep) * 0.25f;
        float step  = minStep + sigma * Math.abs((float) gaussianUnit());
        step = Math.min(step, maxStep);
        step = Math.min(Math.abs(diff), step) * Math.signum(diff);

        return wrapAngle(current + snapToGCD(step));
    }

    /**
     * Full server-rotation computation for one tick.
     * Mutates {@code smoothState[0]} (yaw) and {@code smoothState[1]} (pitch) in place.
     *
     * @param targetYaw    ideal yaw pointing at the entity
     * @param targetPitch  ideal pitch
     * @param smoothState  float[2] carrying the previous server yaw/pitch
     * @param minStep      min degrees/tick
     * @param maxStep      max degrees/tick
     * @return float[2] {newServerYaw, newServerPitch} — already GCD-snapped
     */
    public static float[] stepServerRotation(float targetYaw, float targetPitch,
                                              float[] smoothState,
                                              float minStep, float maxStep) {
        smoothState[0] = smoothToward(smoothState[0], targetYaw,  minStep,        maxStep);
        smoothState[1] = smoothToward(smoothState[1], targetPitch, minStep * 0.3f, maxStep * 0.4f);
        smoothState[1] = clampPitch(smoothState[1]);
        return new float[]{ smoothState[0], smoothState[1] };
    }

    // ── Best attack point on entity AABB ─────────────────────────────────────

    /**
     * Returns the rotation angles toward the point on the entity's bounding box
     * that minimises angular distance from the current view, reducing the step
     * size needed each tick and making the motion look more natural.
     */
    public static float[] getBestRotation(Entity target) {
        return getBestRotation(target,
                mc.thePlayer.rotationYaw,
                mc.thePlayer.rotationPitch);
    }

    public static float[] getBestRotation(Entity target, float cYaw, float cPitch) {
        AxisAlignedBB bb  = target.getEntityBoundingBox();
        double   height   = bb.maxY - bb.minY;

        // Three candidate heights: low / mid / high
        double[] testY = {
            bb.minY + height * 0.1,
            bb.minY + height * 0.5,
            bb.minY + height * 0.9
        };

        // Clamp X/Z to nearest edge of bounding box
        double cx = MathHelper.clamp_double(mc.thePlayer.posX, bb.minX, bb.maxX);
        double cz = MathHelper.clamp_double(mc.thePlayer.posZ, bb.minZ, bb.maxZ);

        float   bestDist = Float.MAX_VALUE;
        float[] best     = getRotationsTo(target.posX, target.posY + target.height * 0.5, target.posZ);

        for (double ty : testY) {
            float[] r    = getRotationsTo(cx, ty, cz);
            float   dist = rotationDist(cYaw, cPitch, r[0], r[1]);
            if (dist < bestDist) { bestDist = dist; best = r; }
        }
        return best;
    }

    /** Raw yaw/pitch toward an arbitrary world point from the player's eye. */
    public static float[] getRotationsTo(double wx, double wy, double wz) {
        double dx   = wx - mc.thePlayer.posX;
        double dy   = wy - (mc.thePlayer.posY + mc.thePlayer.getEyeHeight());
        double dz   = wz - mc.thePlayer.posZ;
        double dist = Math.sqrt(dx * dx + dz * dz);
        float  yaw  = (float) (Math.atan2(dz, dx) * 180.0 / Math.PI) - 90f;
        float  pitch= (float) (-(Math.atan2(dy, dist) * 180.0 / Math.PI));
        return new float[]{ wrapAngle(yaw), clampPitch(pitch) };
    }

    public static float[] getRotationsToEntity(Entity e) {
        return getRotationsTo(e.posX, e.posY + e.height * 0.5, e.posZ);
    }

    // ── Angle math ───────────────────────────────────────────────────────────

    public static float wrapAngle(float a) {
        a %= 360f;
        if (a >= 180f)  a -= 360f;
        if (a < -180f)  a += 360f;
        return a;
    }

    public static float angleDiff(float from, float to) {
        return wrapAngle(to - from);
    }

    public static float clampPitch(float p) {
        return MathHelper.clamp_float(p, -90f, 90f);
    }

    public static float rotationDist(float y1, float p1, float y2, float p2) {
        float dy = angleDiff(y1, y2);
        float dp = p1 - p2;
        return (float) Math.sqrt(dy * dy + dp * dp);
    }

    // ── Can the server rotation actually see the target? ─────────────────────

    /**
     * Checks whether the given yaw/pitch can see the entity — i.e. the angle to
     * the entity center is within {@code fov} degrees.  Used to gate attacks so
     * Polar doesn't see attacks landing outside the sent rotation window.
     */
    public static boolean canSee(Entity e, float yaw, float pitch, float fov) {
        float[] ideal = getRotationsToEntity(e);
        return rotationDist(yaw, pitch, ideal[0], ideal[1]) <= fov;
    }

    // ── Internal helpers ─────────────────────────────────────────────────────

    /** Box-Muller unit normal, clamped to [-3, 3]. */
    private static double gaussianUnit() {
        double u1 = Math.max(1e-10, rng.nextDouble());
        double u2 = rng.nextDouble();
        double z  = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
        return Math.max(-3.0, Math.min(3.0, z));
    }
}
