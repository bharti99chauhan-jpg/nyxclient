package com.portolan.utils;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;

/**
 * Movement helpers — Polar bypass notes
 *
 * What Polar checks on movement:
 *   1. Per-tick velocity deltas:  v_n - v_{n-1} must follow vanilla friction curves.
 *      Overwriting motX/Z to a constant every tick produces a flat-line velocity
 *      trace that looks nothing like vanilla.  Polar flags it as "speed" after ~3 ticks.
 *
 *   2. Acceleration spike on ground: jumping sets motY = 0.42, and in the same tick
 *      the horizontal velocity should come from vanilla's moveEntityWithHeading.
 *      Clients that also set motX/Z on the jump tick produce a simultaneous X/Y/Z
 *      spike — detectable.
 *
 * Fix strategy (LiquidBounce "Strafe" approach):
 *   - Let vanilla compute motX/Z normally (call super / don't cancel).
 *   - In the POST motion event, scale the existing velocity by a factor.
 *   - Ramp the factor up over several ticks instead of snapping (avoids spike check).
 *   - For BHop: only scale while in-air, never on the jump frame itself.
 *   - For direction control: manipulate moveForward / moveStrafe (the INPUT), which
 *     vanilla then funnels through moveEntityWithHeading.  This keeps the acceleration
 *     curve vanilla-shaped; only the direction changes.
 *
 * The INPUT-direction trick (strafe direction fix):
 *   Vanilla computes direction from (moveForward, moveStrafe) relative to rotationYaw.
 *   We override moveForward/moveStrafe to point in the desired direction, let vanilla
 *   compute the motion, then optionally scale in POST.  This produces a path that
 *   matches vanilla physics exactly except for speed.
 */
public final class MovementUtils {

    private static final Minecraft mc = Minecraft.getMinecraft();

    private MovementUtils() {}

    // ── Core: post-physics scale ──────────────────────────────────────────────

    /**
     * Scale horizontal velocity toward {@code targetSpeed} at most {@code rampPerTick}
     * per tick.  Call this in POST motion (after vanilla has already computed the frame).
     *
     * @param rampPerTick  max speed increase per tick — 0.03 is Polar-safe, 0.06 is
     *                     borderline, anything above 0.1 spikes the trace.
     */
    public static void strafeScale(EntityPlayer p, double targetSpeed, double rampPerTick) {
        double curSpeed = getHorizSpeed(p);
        if (curSpeed < 0.001) return;

        // Ramp toward target — never snap
        double newSpeed = Math.min(targetSpeed, curSpeed + rampPerTick);
        // Also never reduce (let vanilla friction handle deceleration naturally)
        if (newSpeed <= curSpeed) return;

        double factor = newSpeed / curSpeed;
        p.motionX *= factor;
        p.motionZ *= factor;
    }

    /**
     * Full strafe direction + speed fix.
     *
     * Sets moveForward/moveStrafe to put the player moving in the direction of
     * their pressed keys relative to their CAMERA yaw (not server yaw — we want
     * the movement direction the player intends).  Then scales in-motion.
     *
     * Call this in PRE motion, before vanilla computes the frame.
     */
    public static void setStrafingInput(EntityPlayer p, float speed) {
        float yaw    = p.rotationYaw;
        float fwd    = p.movementInput.moveForward;
        float strafe = p.movementInput.moveStrafe;
        double mag   = Math.sqrt(fwd * fwd + strafe * strafe);
        if (mag < 0.001) return;

        // Direction in world space
        double moveYaw = Math.toRadians(yaw) - Math.atan2(strafe, fwd);
        p.motionX = -Math.sin(moveYaw) * speed;
        p.motionZ =  Math.cos(moveYaw) * speed;
    }

    // ── BHop helpers ─────────────────────────────────────────────────────────

    /**
     * Returns true on the first tick the player is on the ground — the jump frame.
     * On this tick we jump but do NOT scale horizontal velocity (vanilla already
     * applied moveEntityWithHeading with the correct speed for this frame).
     */
    public static boolean shouldJump(EntityPlayer p) {
        return p.onGround && !mc.gameSettings.keyBindJump.isKeyDown();
    }

    /** True if the player is airborne and past the jump frame (motY is falling). */
    public static boolean isGliding(EntityPlayer p) {
        return !p.onGround && p.motionY < 0.42;
    }

    // ── Vanilla movement formula (reference) ─────────────────────────────────

    /**
     * Vanilla moveEntityWithHeading computes motion as:
     *
     *   float strafe = moveStrafe * 0.98;
     *   float fwd    = moveForward * 0.98;
     *   double mag   = sqrt(strafe² + fwd²);
     *   if (mag >= 0.01) {
     *       mag = max(mag, 1.0);  // normalise — prevents diagonal boost
     *       mag = moveSpeed / mag;
     *       strafe *= mag;  fwd *= mag;
     *       double sin = sin(rotationYaw * PI/180);
     *       double cos = cos(rotationYaw * PI/180);
     *       motionX += strafe*cos - fwd*sin;
     *       motionZ += fwd*cos  + strafe*sin;
     *   }
     *   // Then friction:  motX *= 0.91 * groundFriction  (or 0.91 in air)
     *
     * Our scale factor is applied AFTER this, in POST, so the resulting curve is:
     *   v_n = (v_{n-1} * friction + vanillaAccel) * scale
     * which is shape-identical to vanilla, just faster.
     * Polar accepts this up to ~1.3× base speed before the speed check fires.
     *
     * For anti-cheat-harder servers: use setStrafingInput() instead (input manipulation
     * is harder to detect because it goes through the same code path as a keyboard press).
     */

    // ── Misc helpers ─────────────────────────────────────────────────────────

    public static double getHorizSpeed(EntityPlayer p) {
        return Math.sqrt(p.motionX * p.motionX + p.motionZ * p.motionZ);
    }

    /** Force-move in the direction of pressed keys at exactly {@code speed} blocks/tick. */
    public static void setMotion(EntityPlayer p, double speed) {
        double yaw  = Math.toRadians(p.rotationYaw);
        float  fwd  = p.movementInput.moveForward;
        float  str  = p.movementInput.moveStrafe;
        double mag  = Math.sqrt(fwd * fwd + str * str);
        if (mag < 0.001) { p.motionX = 0; p.motionZ = 0; return; }
        double dir  = Math.toRadians(p.rotationYaw) - Math.atan2(str, fwd);
        p.motionX   = -Math.sin(dir) * speed;
        p.motionZ   =  Math.cos(dir) * speed;
    }

    /** Stop horizontal motion. */
    public static void stop(EntityPlayer p) { p.motionX = 0; p.motionZ = 0; }

    public static boolean isMoving() {
        EntityPlayer p = mc.thePlayer;
        if (p == null) return false;
        return p.movementInput.moveForward != 0 || p.movementInput.moveStrafe != 0;
    }
}
