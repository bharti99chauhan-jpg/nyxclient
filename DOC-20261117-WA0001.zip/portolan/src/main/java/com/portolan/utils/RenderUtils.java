package com.portolan.utils;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.entity.Entity;
import net.minecraft.util.AxisAlignedBB;
import org.lwjgl.opengl.GL11;

import java.awt.*;

public final class RenderUtils {

    private static final Minecraft mc = Minecraft.getMinecraft();

    private RenderUtils() {}

    public static void drawEntityBox(Entity e, Color c, float pt) {
        double rx = mc.getRenderManager().viewerPosX;
        double ry = mc.getRenderManager().viewerPosY;
        double rz = mc.getRenderManager().viewerPosZ;

        double x = e.lastTickPosX + (e.posX - e.lastTickPosX) * pt - rx;
        double y = e.lastTickPosY + (e.posY - e.lastTickPosY) * pt - ry;
        double z = e.lastTickPosZ + (e.posZ - e.lastTickPosZ) * pt - rz;

        AxisAlignedBB bb = e.getEntityBoundingBox().expand(0.05, 0.05, 0.05)
                .offset(-e.posX, -e.posY, -e.posZ)
                .offset(x, y, z);

        GL11.glPushMatrix();
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_DEPTH_TEST);
        GL11.glLineWidth(1.5f);
        GL11.glColor4f(c.getRed()/255f, c.getGreen()/255f, c.getBlue()/255f, c.getAlpha()/255f);
        RenderGlobal.drawOutlinedBoundingBox(bb, c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha());
        GL11.glEnable(GL11.GL_DEPTH_TEST);
        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glPopMatrix();
    }

    public static void drawTracer(Entity e, Color c, float pt) {
        double rx = mc.getRenderManager().viewerPosX;
        double ry = mc.getRenderManager().viewerPosY;
        double rz = mc.getRenderManager().viewerPosZ;

        double ex = e.lastTickPosX + (e.posX - e.lastTickPosX) * pt - rx;
        double ey = e.lastTickPosY + (e.posY - e.lastTickPosY) * pt - ry + e.height * 0.5;
        double ez = e.lastTickPosZ + (e.posZ - e.lastTickPosZ) * pt - rz;

        GL11.glPushMatrix();
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_DEPTH_TEST);
        GL11.glLineWidth(1.2f);
        GL11.glColor4f(c.getRed()/255f, c.getGreen()/255f, c.getBlue()/255f, c.getAlpha()/255f);
        GL11.glBegin(GL11.GL_LINES);
        GL11.glVertex3d(0, 0, 0);
        GL11.glVertex3d(ex, ey, ez);
        GL11.glEnd();
        GL11.glEnable(GL11.GL_DEPTH_TEST);
        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glPopMatrix();
    }
}
