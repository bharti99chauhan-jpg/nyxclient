package com.portolan.event.events;

import com.portolan.event.Event;

public class EventRender2D extends Event {
    private final float partialTicks;
    public EventRender2D(float pt) { this.partialTicks = pt; }
    public float getPartialTicks() { return partialTicks; }
}
