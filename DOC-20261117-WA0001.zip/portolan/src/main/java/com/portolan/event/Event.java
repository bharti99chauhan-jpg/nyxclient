package com.portolan.event;

public class Event {
    private boolean cancelled = false;

    public boolean isCancelled() { return cancelled; }
    public void setCancelled(boolean c) { this.cancelled = c; }
    public boolean isCancellable() { return false; }
}
