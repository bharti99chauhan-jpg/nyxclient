package com.portolan.event.events;

import com.portolan.event.Event;

public class EventRender3D extends Event {
    private final float partialTicks;
    public EventRender3D(float pt) { this.partialTicks = pt; }
    public float getPartialTicks() { return partialTicks; }
}
