package com.portolan.event.events;

import com.portolan.event.Event;

public class EventStep extends Event {
    private float stepHeight;
    public EventStep(float h) { this.stepHeight = h; }
    public float getStepHeight()      { return stepHeight; }
    public void  setStepHeight(float h){ this.stepHeight = h; }
}
