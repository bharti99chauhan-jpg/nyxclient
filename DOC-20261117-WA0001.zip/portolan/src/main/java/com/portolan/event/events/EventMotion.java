package com.portolan.event.events;

import com.portolan.event.Cancellable;

public class EventMotion extends Cancellable {

    public enum State { PRE, POST }

    private final State state;
    private float yaw, pitch;
    private double x, y, z;
    private boolean onGround;
    private boolean rotationModified = false;
    private boolean onGroundModified = false;

    public EventMotion(State state, float yaw, float pitch,
                       double x, double y, double z, boolean onGround) {
        this.state    = state;
        this.yaw      = yaw;
        this.pitch    = pitch;
        this.x        = x;
        this.y        = y;
        this.z        = z;
        this.onGround = onGround;
    }

    // ── getters ──────────────────────────────────────────────────────────────
    public State   getState()    { return state; }
    public float   getYaw()      { return yaw; }
    public float   getPitch()    { return pitch; }
    public double  getX()        { return x; }
    public double  getY()        { return y; }
    public double  getZ()        { return z; }
    public boolean isOnGround()  { return onGround; }
    public boolean isPre()       { return state == State.PRE; }
    public boolean isPost()      { return state == State.POST; }
    public boolean isRotationModified()  { return rotationModified; }
    public boolean isOnGroundModified()  { return onGroundModified; }

    // ── setters — set flag on rotation change ────────────────────────────────
    public void setYaw(float yaw)       { this.yaw = yaw;     this.rotationModified = true; }
    public void setPitch(float pitch)   { this.pitch = pitch; this.rotationModified = true; }
    public void setX(double x)          { this.x = x; }
    public void setY(double y)          { this.y = y; }
    public void setZ(double z)          { this.z = z; }
    public void setOnGround(boolean og) { this.onGround = og; this.onGroundModified = true; }
}
