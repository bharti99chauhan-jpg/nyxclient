package com.portolan.event;

import java.lang.reflect.Method;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class EventBus {

    // listener → list of (eventClass, method)
    private final Map<Object, List<MethodHandle>> registry = new ConcurrentHashMap<>();

    private static class MethodHandle {
        final Class<?> eventType;
        final Method   method;
        MethodHandle(Class<?> t, Method m) { eventType = t; method = m; }
    }

    public void register(Object listener) {
        List<MethodHandle> handles = new ArrayList<>();
        for (Method m : listener.getClass().getMethods()) {
            if (!m.isAnnotationPresent(EventTarget.class)) continue;
            if (m.getParameterCount() != 1) continue;
            m.setAccessible(true);
            handles.add(new MethodHandle(m.getParameterTypes()[0], m));
        }
        if (!handles.isEmpty()) registry.put(listener, handles);
    }

    public void unregister(Object listener) {
        registry.remove(listener);
    }

    public <T extends Event> T post(T event) {
        for (Map.Entry<Object, List<MethodHandle>> entry : registry.entrySet()) {
            for (MethodHandle h : entry.getValue()) {
                if (!h.eventType.isInstance(event)) continue;
                if (event.isCancellable() && event.isCancelled()) continue;
                try { h.method.invoke(entry.getKey(), event); }
                catch (Exception ignored) {}
            }
        }
        return event;
    }
}
