package com.portolan.event;

public class Cancellable extends Event {
    @Override
    public boolean isCancellable() { return true; }
}
