package com.aquastrike.gui;

import com.aquastrike.AquaStrike;
import com.aquastrike.module.Category;
import com.aquastrike.module.Module;
import com.aquastrike.module.setting.BoolSetting;
import com.aquastrike.module.setting.ListSetting;
import com.aquastrike.module.setting.NumberSetting;
import com.aquastrike.module.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;

import java.io.IOException;
import java.util.List;

/**
 * ClickGUI — fixed slider dragging.
 *
 * Root bug: dragSettingSlot (int) was never reset because mouseReleased
 * (func_146286_b) was not overridden. After the first NumberSetting click
 * dragSettingSlot stayed != -1 forever and every subsequent draw updated
 * the wrong value. Now we track the actual Setting<?> reference and reset
 * it in func_146286_b.
 */
public class ClickGUI extends GuiScreen {

    // ── Colour palette ────────────────────────────────────────────────────
    private static final int COL_BG       = 0xE0101014;
    private static final int COL_TAB      = 0xFF1C1C22;
    private static final int COL_TAB_SEL  = 0xFF2A2AFF;
    private static final int COL_MOD_ON   = 0xFF2255FF;
    private static final int COL_MOD_OFF  = 0xFF232328;
    private static final int COL_MOD_HOV  = 0xFF2D2D35;
    private static final int COL_SETTING  = 0xFF191919;
    private static final int COL_TEXT     = 0xFFEEEEEE;
    private static final int COL_VAL      = 0xFF8888CC;
    private static final int COL_SLIDER   = 0xFF3366FF;

    // ── Layout constants ──────────────────────────────────────────────────
    private static final int TAB_H    = 20;
    private static final int MOD_H    = 16;
    private static final int SET_H    = 14;
    private static final int PANEL_X  = 4;
    private static final int PANEL_Y  = 22;
    private static final int PANEL_W  = 160;

    // ── State ─────────────────────────────────────────────────────────────
    private Category selectedCategory = Category.COMBAT;
    private Module   expandedModule   = null;
    private int      scrollOffset     = 0;

    // Slider drag — track the actual setting, not an index
    private NumberSetting draggingSetting  = null;   // non-null while drag active
    private int           dragStartX       = 0;
    private double        dragStartValue   = 0;
    private int           dragSliderX      = 0;      // left edge of the slider bar
    private int           dragSliderW      = 0;      // width of the slider bar

    // ─────────────────────────────────────────────────────────────────────

    @Override
    public boolean doesGuiPauseGame() { return false; }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        // Live-drag update — apply before we draw so the new value renders
        if (draggingSetting != null && dragSliderW > 0) {
            double t = (double)(mouseX - dragSliderX) / dragSliderW;
            t = Math.max(0.0, Math.min(1.0, t));
            double newVal = draggingSetting.getMin()
                    + t * (draggingSetting.getMax() - draggingSetting.getMin());
            // Snap to increment
            double inc = draggingSetting.getIncrement();
            if (inc > 0) newVal = Math.round(newVal / inc) * inc;
            newVal = Math.max(draggingSetting.getMin(), Math.min(draggingSetting.getMax(), newVal));
            draggingSetting.setValue(newVal);
        }

        // ── Background ────────────────────────────────────────────────────
        drawRect(0, 0, width, height, 0x60000000);
        drawRect(PANEL_X, PANEL_Y, PANEL_X + PANEL_W, height - 2, COL_BG);

        // ── Category tabs ─────────────────────────────────────────────────
        Category[] cats  = Category.values();
        int tabW = PANEL_W / cats.length;
        for (int i = 0; i < cats.length; i++) {
            int tx   = PANEL_X + i * tabW;
            boolean sel = cats[i] == selectedCategory;
            drawRect(tx, PANEL_Y - TAB_H, tx + tabW, PANEL_Y, sel ? COL_TAB_SEL : COL_TAB);
            String label = cats[i].name().substring(0,1)
                    + cats[i].name().substring(1).toLowerCase();
            int tw = fontRendererObj.getStringWidth(label);
            fontRendererObj.drawString(label,
                    tx + (tabW - tw) / 2.0f, PANEL_Y - TAB_H + 6, COL_TEXT, false);
        }

        // ── Module list ───────────────────────────────────────────────────
        List<Module> mods = AquaStrike.moduleManager.getModulesByCategory(selectedCategory);
        int y = PANEL_Y + 2 - scrollOffset;

        for (Module mod : mods) {
            if (y + MOD_H < PANEL_Y || y > height - 2) { y += MOD_H; continue; }

            boolean hovered = mouseX >= PANEL_X && mouseX < PANEL_X + PANEL_W
                    && mouseY >= y && mouseY < y + MOD_H;
            int bg = mod.isEnabled() ? COL_MOD_ON : (hovered ? COL_MOD_HOV : COL_MOD_OFF);
            drawRect(PANEL_X, y, PANEL_X + PANEL_W, y + MOD_H, bg);
            fontRendererObj.drawString(mod.getName(), PANEL_X + 3.0f, y + 4.0f, COL_TEXT, false);

            String suffix = mod.getSuffix();
            if (suffix != null) {
                int sw = fontRendererObj.getStringWidth(suffix);
                fontRendererObj.drawString(suffix,
                        PANEL_X + PANEL_W - sw - 3.0f, y + 4.0f, COL_VAL, false);
            }
            y += MOD_H;

            // Settings for expanded module
            if (mod == expandedModule) {
                List<Setting<?>> settings = mod.getSettings();
                for (int s = 0; s < settings.size(); s++) {
                    Setting<?> set = settings.get(s);
                    if (y + SET_H < PANEL_Y || y > height - 2) { y += SET_H; continue; }

                    drawRect(PANEL_X, y, PANEL_X + PANEL_W, y + SET_H, COL_SETTING);

                    if (set instanceof NumberSetting) {
                        NumberSetting ns = (NumberSetting) set;
                        int sx = PANEL_X + 3;
                        int sw = PANEL_W - 6;
                        double ratio = (ns.getValue() - ns.getMin())
                                / (ns.getMax() - ns.getMin());
                        int filled = (int)(sw * ratio);
                        drawRect(sx, y + 9, sx + sw, y + 12, 0xFF333340);
                        drawRect(sx, y + 9, sx + filled, y + 12, COL_SLIDER);
                        fontRendererObj.drawString(
                                "  " + ns.getName() + ": " + fmtNum(ns.getValue()),
                                (float) PANEL_X + 3, (float) y + 2, COL_TEXT, false);

                    } else if (set instanceof BoolSetting) {
                        BoolSetting bs = (BoolSetting) set;
                        int col = bs.isEnabled() ? 0xFF44CC44 : 0xFFCC4444;
                        drawRect(PANEL_X + PANEL_W - 11, y + 3, PANEL_X + PANEL_W - 3, y + 11, col);
                        fontRendererObj.drawString(
                                "  " + bs.getName(), (float) PANEL_X + 3, (float) y + 3, COL_TEXT, false);

                    } else if (set instanceof ListSetting) {
                        ListSetting ls = (ListSetting) set;
                        fontRendererObj.drawString(
                                "  " + ls.getName() + ": " + ls.getValue(),
                                (float) PANEL_X + 3, (float) y + 3, COL_TEXT, false);
                    }
                    y += SET_H;
                }
            }
        }

        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    // ── Mouse clicked ─────────────────────────────────────────────────────
    @Override
    protected void mouseClicked(int mouseX, int mouseY, int button) throws IOException {
        // Category tab click
        Category[] cats = Category.values();
        int tabW = PANEL_W / cats.length;
        for (int i = 0; i < cats.length; i++) {
            int tx = PANEL_X + i * tabW;
            if (mouseX >= tx && mouseX < tx + tabW
                    && mouseY >= PANEL_Y - TAB_H && mouseY < PANEL_Y) {
                selectedCategory = cats[i];
                expandedModule   = null;
                scrollOffset     = 0;
                return;
            }
        }

        List<Module> mods = AquaStrike.moduleManager.getModulesByCategory(selectedCategory);
        int y = PANEL_Y + 2 - scrollOffset;

        for (Module mod : mods) {
            boolean inRow = mouseX >= PANEL_X && mouseX < PANEL_X + PANEL_W
                    && mouseY >= y && mouseY < y + MOD_H;
            int rowY = y;
            y += MOD_H;

            if (mod == expandedModule) {
                List<Setting<?>> settings = mod.getSettings();
                for (Setting<?> set : settings) {
                    boolean inSet = mouseX >= PANEL_X && mouseX < PANEL_X + PANEL_W
                            && mouseY >= y && mouseY < y + SET_H;
                    if (inSet) {
                        handleSettingClick(set, mouseX, mouseY, button, y);
                        return;
                    }
                    y += SET_H;
                }
            }

            if (inRow) {
                if (button == 0) {
                    mod.toggle();
                } else if (button == 1) {
                    expandedModule = (expandedModule == mod) ? null : mod;
                }
                return;
            }
        }

        super.mouseClicked(mouseX, mouseY, button);
    }

    private void handleSettingClick(Setting<?> set, int mouseX, int mouseY,
                                    int button, int rowY) {
        if (set instanceof BoolSetting) {
            if (button == 0) ((BoolSetting) set).toggle();

        } else if (set instanceof ListSetting) {
            ((ListSetting) set).cycle();

        } else if (set instanceof NumberSetting) {
            NumberSetting ns = (NumberSetting) set;
            int sx = PANEL_X + 3;
            int sw = PANEL_W - 6;
            // Start drag — store geometry so drawScreen can recalculate on movement
            draggingSetting = ns;
            dragStartX      = mouseX;
            dragStartValue  = ns.getValue();
            dragSliderX     = sx;
            dragSliderW     = sw;
            // Apply immediately on click
            double t = (double)(mouseX - sx) / sw;
            t = Math.max(0.0, Math.min(1.0, t));
            double newVal = ns.getMin() + t * (ns.getMax() - ns.getMin());
            double inc = ns.getIncrement();
            if (inc > 0) newVal = Math.round(newVal / inc) * inc;
            newVal = Math.max(ns.getMin(), Math.min(ns.getMax(), newVal));
            ns.setValue(newVal);
        }
    }

    // ── Mouse released — CRITICAL: resets slider drag ─────────────────────
    @Override
    protected void mouseReleased(int mouseX, int mouseY, int state) {
        draggingSetting = null;
        super.mouseReleased(mouseX, mouseY, state);
    }

    // ── Scroll ────────────────────────────────────────────────────────────
    @Override
    public void handleMouseInput() throws IOException {
        super.handleMouseInput();
        int delta = org.lwjgl.input.Mouse.getEventDWheel();
        if (delta != 0) {
            scrollOffset -= delta / 10;
            scrollOffset = Math.max(0, scrollOffset);
        }
    }

    // ── Close on Escape ───────────────────────────────────────────────────
    @Override
    protected void keyTyped(char typedChar, int keyCode) throws IOException {
        if (keyCode == 1) Minecraft.getMinecraft().displayGuiScreen(null);
    }

    // ── Helper ────────────────────────────────────────────────────────────
    private String fmtNum(double v) {
        if (v == Math.floor(v)) return String.valueOf((int) v);
        return String.format("%.2f", v);
    }
}
