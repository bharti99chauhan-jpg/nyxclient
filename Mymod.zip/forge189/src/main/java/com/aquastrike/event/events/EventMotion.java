package com.aquastrike.event.events;

import com.aquastrike.event.Cancellable;

/**
 * Fired once per tick before (PRE) and after (POST) the motion packet is sent.
 * PRE is where silent aura sets its server-side rotation.
 * POST is where it restores the client rotation.
 */
public class EventMotion extends Cancellable {

    /** Alias kept for backward compat; use Type in new code. */
    public enum State { PRE, POST }
    public enum Type  { PRE, POST }

    private final Type type;
    private float yaw;
    private float pitch;
    private double x, y, z;
    private boolean onGround;
    private boolean onGroundModified = false;

    public EventMotion(Type type, float yaw, float pitch, double x, double y, double z, boolean onGround) {
        this.type     = type;
        this.yaw      = yaw;
        this.pitch    = pitch;
        this.x        = x;
        this.y        = y;
        this.z        = z;
        this.onGround = onGround;
    }

    /** Legacy constructor — maps State to Type. */
    public EventMotion(State state, float yaw, float pitch, double x, double y, double z, boolean onGround) {
        this(state == State.PRE ? Type.PRE : Type.POST, yaw, pitch, x, y, z, onGround);
    }

    public Type    getType()    { return type;     }
    public boolean isPre()      { return type == Type.PRE;  }
    public boolean isPost()     { return type == Type.POST; }
    public float   getYaw()     { return yaw;      }
    public float   getPitch()   { return pitch;    }
    public double  getX()       { return x;        }
    public double  getY()       { return y;        }
    public double  getZ()       { return z;        }
    public boolean isOnGround() { return onGround; }
    public boolean getOnGround(){ return onGround; }
    public boolean isOnGroundModified() { return onGroundModified; }

    public void setYaw(float yaw)        { this.yaw      = yaw;      }
    public void setPitch(float pitch)    { this.pitch    = pitch;    }
    public void setX(double x)          { this.x        = x;        }
    public void setY(double y)          { this.y        = y;        }
    public void setZ(double z)          { this.z        = z;        }
    public void setOnGround(boolean og)  {
        this.onGround = og;
        this.onGroundModified = true;
    }
}
