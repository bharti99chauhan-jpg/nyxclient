package com.aquastrike.event.events;

import com.aquastrike.event.Event;

public class EventStep extends Event {
    private float stepHeight;
    public EventStep(float stepHeight) { this.stepHeight = stepHeight; }
    public float getStepHeight() { return stepHeight; }
    public void setStepHeight(float h) { this.stepHeight = h; }
}
