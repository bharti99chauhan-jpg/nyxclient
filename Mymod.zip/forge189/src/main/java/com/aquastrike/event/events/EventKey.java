package com.aquastrike.event.events;

import com.aquastrike.event.Event;

public class EventKey extends Event {
    private final int keyCode;

    public EventKey(int keyCode) {
        this.keyCode = keyCode;
    }

    public int getKeyCode() { return keyCode; }
}
