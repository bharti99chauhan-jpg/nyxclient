package com.aquastrike.event;

public abstract class Event {}
