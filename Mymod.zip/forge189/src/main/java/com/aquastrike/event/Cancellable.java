package com.aquastrike.event;

public class Cancellable extends Event {
    private boolean cancelled;
    public boolean isCancelled() { return cancelled; }
    public void setCancelled(boolean c) { this.cancelled = c; }
}
