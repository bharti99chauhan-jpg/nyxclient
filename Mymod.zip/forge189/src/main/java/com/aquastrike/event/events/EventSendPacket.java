package com.aquastrike.event.events;

import com.aquastrike.event.Cancellable;
import net.minecraft.network.Packet;

public class EventSendPacket extends Cancellable {
    private Packet<?> packet;

    public EventSendPacket(Packet<?> packet) {
        this.packet = packet;
    }

    public Packet<?> getPacket()           { return packet; }
    public void setPacket(Packet<?> p)     { this.packet = p; }
}
