package com.aquastrike.event;

import java.lang.reflect.Method;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Simple annotation-based EventBus.
 * Listeners annotate handler methods with @EventTarget.
 */
public class EventBus {

    private final Map<Class<?>, List<MethodEntry>> registry = new ConcurrentHashMap<>();

    public void register(Object listener) {
        for (Method m : listener.getClass().getDeclaredMethods()) {
            if (!m.isAnnotationPresent(EventTarget.class)) continue;
            if (m.getParameterCount() != 1) continue;
            Class<?> eventType = m.getParameterTypes()[0];
            m.setAccessible(true);
            registry.computeIfAbsent(eventType, k -> Collections.synchronizedList(new ArrayList<>()))
                    .add(new MethodEntry(listener, m));
        }
    }

    public void unregister(Object listener) {
        for (List<MethodEntry> list : registry.values()) {
            list.removeIf(e -> e.instance == listener);
        }
    }

    public <T extends Event> T post(T event) {
        List<MethodEntry> handlers = registry.get(event.getClass());
        if (handlers == null) return event;
        for (MethodEntry entry : handlers) {
            try {
                entry.method.invoke(entry.instance, event);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            if (event instanceof Cancellable && ((Cancellable) event).isCancelled()) break;
        }
        return event;
    }

    private static class MethodEntry {
        final Object instance;
        final Method method;
        MethodEntry(Object i, Method m) { instance = i; method = m; }
    }
}
