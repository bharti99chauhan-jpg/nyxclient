package com.aquastrike.event.events;

import com.aquastrike.event.Event;
import net.minecraft.client.renderer.RenderGlobal;

public class EventRender3D extends Event {
    private final float partialTicks;
    private final RenderGlobal context;

    public EventRender3D(float partialTicks, RenderGlobal context) {
        this.partialTicks = partialTicks;
        this.context = context;
    }

    public float getPartialTicks() { return partialTicks; }
    public RenderGlobal getContext() { return context; }
}
