package com.aquastrike.utils;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;

import java.util.Random;

public class RotationUtils {

    private static final Minecraft mc  = Minecraft.getMinecraft();
    private static final Random    rng = new Random();

    // -------------------------------------------------------------------------
    // GCD / Polar bypass
    // Polar flags rotations that don't match sensitivity rounding.
    // Formula: gcd = (sens * 0.6 + 0.2)^3 * 8.0
    // Every delta we send must be a multiple of this value.
    // -------------------------------------------------------------------------

    public static float getGCD() {
        double f = mc.gameSettings.mouseSensitivity * 0.6 + 0.2;
        return (float) (f * f * f * 8.0);
    }

    public static float applyGCD(float delta) {
        float gcd = getGCD();
        if (gcd == 0f) return delta;
        return Math.round(delta / gcd) * gcd;
    }

    public static float[] applyGCDFix(float yawDelta, float pitchDelta) {
        float gcd = getGCD();
        if (gcd == 0f) return new float[]{yawDelta, pitchDelta};
        return new float[]{
            Math.round(yawDelta   / gcd) * gcd,
            Math.round(pitchDelta / gcd) * gcd
        };
    }

    // -------------------------------------------------------------------------
    // Geometry helpers
    // -------------------------------------------------------------------------

    public static float[] getRotationsToPos(double x, double y, double z) {
        double dx   = x - mc.thePlayer.posX;
        double dy   = y - (mc.thePlayer.posY + mc.thePlayer.getEyeHeight());
        double dz   = z - mc.thePlayer.posZ;
        double dist = Math.sqrt(dx * dx + dz * dz);
        float  yaw  = (float)(Math.atan2(dz, dx) * 180.0 / Math.PI) - 90f;
        float  pitch= (float)-(Math.atan2(dy, dist) * 180.0 / Math.PI);
        return new float[]{yaw, pitch};
    }

    /**
     * Find the point on {@code e}'s AABB that requires the least yaw/pitch
     * change from {@code currentYaw}/{@code currentPitch}.
     * This is what real Vape does — it aims at the closest hitbox point,
     * not the geometric centre, which minimises detectable rotation size.
     */
    public static float[] getRotationsToBestPoint(Entity e,
                                                   float currentYaw,
                                                   float currentPitch) {
        AxisAlignedBB bb = e.getEntityBoundingBox().expand(0, 0, 0);

        // Sample 5 points: top, bottom, centre, closest-X, closest-Z edges
        double[] ys = { bb.minY + (bb.maxY - bb.minY) * 0.2,
                        bb.minY + (bb.maxY - bb.minY) * 0.5,
                        bb.minY + (bb.maxY - bb.minY) * 0.8 };

        double cx = MathHelper.clamp_double(mc.thePlayer.posX, bb.minX, bb.maxX);
        double cz = MathHelper.clamp_double(mc.thePlayer.posZ, bb.minZ, bb.maxZ);

        float bestScore = Float.MAX_VALUE;
        float[] bestRot = getRotationsToPos(e.posX, e.posY + e.height * 0.5, e.posZ);

        for (double y : ys) {
            float[] rot = getRotationsToPos(cx, y, cz);
            float score = rotationDistance(currentYaw, currentPitch, rot[0], rot[1]);
            if (score < bestScore) {
                bestScore = score;
                bestRot   = rot;
            }
        }
        return bestRot;
    }

    public static float[] getRotationsToEntity(Entity e) {
        return getRotationsToPos(e.posX, e.posY + e.height * 0.5, e.posZ);
    }

    // -------------------------------------------------------------------------
    // Angle math
    // -------------------------------------------------------------------------

    public static float wrapAngle(float a) {
        a %= 360f;
        if (a >= 180f)  a -= 360f;
        if (a < -180f)  a += 360f;
        return a;
    }

    public static float clampPitch(float p) {
        return MathHelper.clamp_float(p, -90f, 90f);
    }

    public static float angleDiff(float from, float to) {
        return wrapAngle(to - from);
    }

    public static float rotationDistance(float y1, float p1, float y2, float p2) {
        float dy = angleDiff(y1, y2);
        float dp = p1 - p2;
        return (float) Math.sqrt(dy * dy + dp * dp);
    }

    // -------------------------------------------------------------------------
    // Smooth rotation — applies GCD at each step (critical for Polar)
    // -------------------------------------------------------------------------

    /**
     * Move {@code current} toward {@code target} by at most {@code maxStep}
     * degrees per tick, with GCD applied to the delta.
     * This is what every rotation tick should use.
     */
    public static float smoothTo(float current, float target, float maxStep) {
        float diff = angleDiff(current, target);
        float step = MathHelper.clamp_float(diff, -maxStep, maxStep);
        return wrapAngle(current + applyGCD(step));
    }

    /**
     * Polar-safe smooth step: applies a randomised step in [minStep, maxStep]
     * so consecutive ticks never produce a perfectly constant delta.
     */
    public static float smoothToRandom(float current, float target,
                                        float minStep, float maxStep) {
        float diff = angleDiff(current, target);
        if (Math.abs(diff) < 0.01f) return target;
        float range = maxStep - minStep;
        float step  = minStep + (float)(rng.nextDouble() * range);
        step = MathHelper.clamp_float(diff, -step, step);
        return wrapAngle(current + applyGCD(step));
    }

    /**
     * Exponential ease-in toward target — feels more like a human flick
     * that overshoots slightly then settles.
     * {@code factor} ∈ [0.1, 1.0]; higher = faster.
     */
    public static float easeToward(float current, float target, float factor) {
        float diff  = angleDiff(current, target);
        float delta = diff * MathHelper.clamp_float(factor, 0.05f, 1.0f);
        // ensure we never go below one GCD unit per tick if still moving
        float gcd   = getGCD();
        if (Math.abs(delta) > 0 && Math.abs(delta) < gcd) {
            delta = Math.signum(delta) * gcd;
        }
        return wrapAngle(current + applyGCD(delta));
    }

    // -------------------------------------------------------------------------
    // Human-like noise
    // -------------------------------------------------------------------------

    /** Box-Muller Gaussian, clamped to ±3σ. */
    public static float gaussian(float mean, float sigma) {
        double u1 = 1.0 - rng.nextDouble();
        double u2 = 1.0 - rng.nextDouble();
        double z  = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
        return (float) MathHelper.clamp_double(mean + sigma * z,
                mean - 3 * sigma, mean + 3 * sigma);
    }

    /** Polar-decomposed jitter: applies noise along the arc toward target. */
    public static float[] polarJitter(float currentYaw, float currentPitch,
                                       float targetYaw,  float targetPitch,
                                       float sigma) {
        float dYaw   = angleDiff(currentYaw,   targetYaw);
        float dPitch = angleDiff(currentPitch, targetPitch);
        float bearing = (float) Math.atan2(dPitch, dYaw);
        float noise   = gaussian(0, sigma);
        float jitterYaw   = (float)(noise * Math.cos(bearing));
        float jitterPitch = (float)(noise * Math.sin(bearing)) * 0.5f;
        return new float[]{
            applyGCD(jitterYaw),
            applyGCD(jitterPitch)
        };
    }
}
