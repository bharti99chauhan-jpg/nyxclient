package com.aquastrike.utils;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.util.AxisAlignedBB;
import org.lwjgl.opengl.GL11;

import java.awt.*;

public class RenderUtils {

    private static final Minecraft mc = Minecraft.getMinecraft();

    // ---- 2D -----------------------------------------------------------------

    public static void draw2DRect(int x, int y, int w, int h, int color) {
        Gui.drawRect(x, y, x + w, y + h, color);
    }

    public static void drawOutlinedRect(int x, int y, int w, int h, int color) {
        draw2DRect(x,         y,         w,  1, color);
        draw2DRect(x,         y + h - 1, w,  1, color);
        draw2DRect(x,         y,         1,  h, color);
        draw2DRect(x + w - 1, y,         1,  h, color);
    }

    public static int rgba(int r, int g, int b, int a) {
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    // ---- 3D boxes (ESP) -----------------------------------------------------

    public static void drawEntityBox(Entity e, Color color, boolean filled) {
        double px = mc.getRenderManager().viewerPosX;
        double py = mc.getRenderManager().viewerPosY;
        double pz = mc.getRenderManager().viewerPosZ;

        double x1 = e.posX - e.width  / 2.0 - px;
        double y1 = e.posY            - py;
        double z1 = e.posZ - e.width  / 2.0 - pz;
        double x2 = e.posX + e.width  / 2.0 - px;
        double y2 = e.posY + e.height      - py;
        double z2 = e.posZ + e.width  / 2.0 - pz;

        AxisAlignedBB bb = new AxisAlignedBB(x1, y1, z1, x2, y2, z2);

        GL11.glPushMatrix();
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_DEPTH_TEST);
        GL11.glDepthMask(false);
        GL11.glLineWidth(1.5f);

        GL11.glColor4f(color.getRed()   / 255f,
                       color.getGreen() / 255f,
                       color.getBlue()  / 255f,
                       color.getAlpha() / 255f);

        if (filled) {
            drawFilledBB(bb);
        }
        drawOutlinedBB(bb);

        GL11.glDepthMask(true);
        GL11.glEnable(GL11.GL_DEPTH_TEST);
        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glPopMatrix();
    }

    private static void drawOutlinedBB(AxisAlignedBB bb) {
        Tessellator tess = Tessellator.getInstance();
        WorldRenderer wr = tess.getWorldRenderer();
        wr.begin(GL11.GL_LINE_STRIP, DefaultVertexFormats.POSITION);
        // bottom loop
        wr.pos(bb.minX,bb.minY,bb.minZ).endVertex();
        wr.pos(bb.maxX,bb.minY,bb.minZ).endVertex();
        wr.pos(bb.maxX,bb.minY,bb.maxZ).endVertex();
        wr.pos(bb.minX,bb.minY,bb.maxZ).endVertex();
        wr.pos(bb.minX,bb.minY,bb.minZ).endVertex();
        tess.draw();
        wr.begin(GL11.GL_LINE_STRIP, DefaultVertexFormats.POSITION);
        // top loop
        wr.pos(bb.minX,bb.maxY,bb.minZ).endVertex();
        wr.pos(bb.maxX,bb.maxY,bb.minZ).endVertex();
        wr.pos(bb.maxX,bb.maxY,bb.maxZ).endVertex();
        wr.pos(bb.minX,bb.maxY,bb.maxZ).endVertex();
        wr.pos(bb.minX,bb.maxY,bb.minZ).endVertex();
        tess.draw();
        wr.begin(GL11.GL_LINES, DefaultVertexFormats.POSITION);
        // verticals
        wr.pos(bb.minX,bb.minY,bb.minZ).endVertex(); wr.pos(bb.minX,bb.maxY,bb.minZ).endVertex();
        wr.pos(bb.maxX,bb.minY,bb.minZ).endVertex(); wr.pos(bb.maxX,bb.maxY,bb.minZ).endVertex();
        wr.pos(bb.maxX,bb.minY,bb.maxZ).endVertex(); wr.pos(bb.maxX,bb.maxY,bb.maxZ).endVertex();
        wr.pos(bb.minX,bb.minY,bb.maxZ).endVertex(); wr.pos(bb.minX,bb.maxY,bb.maxZ).endVertex();
        tess.draw();
    }

    private static void drawFilledBB(AxisAlignedBB bb) {
        Tessellator tess = Tessellator.getInstance();
        WorldRenderer wr = tess.getWorldRenderer();
        wr.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION);
        // 6 faces
        wr.pos(bb.minX,bb.minY,bb.minZ).endVertex(); wr.pos(bb.maxX,bb.minY,bb.minZ).endVertex();
        wr.pos(bb.maxX,bb.minY,bb.maxZ).endVertex(); wr.pos(bb.minX,bb.minY,bb.maxZ).endVertex();
        wr.pos(bb.minX,bb.maxY,bb.minZ).endVertex(); wr.pos(bb.maxX,bb.maxY,bb.minZ).endVertex();
        wr.pos(bb.maxX,bb.maxY,bb.maxZ).endVertex(); wr.pos(bb.minX,bb.maxY,bb.maxZ).endVertex();
        wr.pos(bb.minX,bb.minY,bb.minZ).endVertex(); wr.pos(bb.minX,bb.maxY,bb.minZ).endVertex();
        wr.pos(bb.minX,bb.maxY,bb.maxZ).endVertex(); wr.pos(bb.minX,bb.minY,bb.maxZ).endVertex();
        wr.pos(bb.maxX,bb.minY,bb.minZ).endVertex(); wr.pos(bb.maxX,bb.maxY,bb.minZ).endVertex();
        wr.pos(bb.maxX,bb.maxY,bb.maxZ).endVertex(); wr.pos(bb.maxX,bb.minY,bb.maxZ).endVertex();
        wr.pos(bb.minX,bb.minY,bb.minZ).endVertex(); wr.pos(bb.maxX,bb.minY,bb.minZ).endVertex();
        wr.pos(bb.maxX,bb.maxY,bb.minZ).endVertex(); wr.pos(bb.minX,bb.maxY,bb.minZ).endVertex();
        wr.pos(bb.minX,bb.minY,bb.maxZ).endVertex(); wr.pos(bb.maxX,bb.minY,bb.maxZ).endVertex();
        wr.pos(bb.maxX,bb.maxY,bb.maxZ).endVertex(); wr.pos(bb.minX,bb.maxY,bb.maxZ).endVertex();
        tess.draw();
    }

    // ---- tracer line --------------------------------------------------------

    public static void drawTracer(Entity e, Color color) {
        double px = mc.getRenderManager().viewerPosX;
        double py = mc.getRenderManager().viewerPosY;
        double pz = mc.getRenderManager().viewerPosZ;
        double tx = e.posX - px;
        double ty = e.posY + e.height / 2.0 - py;
        double tz = e.posZ - pz;

        GL11.glPushMatrix();
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_DEPTH_TEST);
        GL11.glLineWidth(1.0f);
        GL11.glColor4f(color.getRed()/255f, color.getGreen()/255f,
                       color.getBlue()/255f, color.getAlpha()/255f);

        Tessellator tess = Tessellator.getInstance();
        WorldRenderer wr = tess.getWorldRenderer();
        wr.begin(GL11.GL_LINES, DefaultVertexFormats.POSITION);
        wr.pos(0, mc.thePlayer.getEyeHeight(), 0).endVertex();
        wr.pos(tx, ty, tz).endVertex();
        tess.draw();

        GL11.glEnable(GL11.GL_DEPTH_TEST);
        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glPopMatrix();
    }
}
