package com.aquastrike.mixin;

import com.aquastrike.AquaStrike;
import com.aquastrike.event.events.EventMotion;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.network.play.client.C03PacketPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(EntityPlayerSP.class)
public class MixinEntityPlayerSP {

    /**
     * Fires EventMotion PRE before the motion packet is assembled,
     * then EventMotion POST with the actual values so silent-aura can
     * inject its server yaw/pitch into the outgoing C03/C06 packet.
     */
    @Inject(method = "onUpdateWalkingPlayer", at = @At("HEAD"))
    private void onUpdatePre(CallbackInfo ci) {
        EntityPlayerSP player = (EntityPlayerSP)(Object) this;
        EventMotion event = new EventMotion(
                EventMotion.Type.PRE,
                player.rotationYaw,
                player.rotationPitch,
                player.posX,
                player.posY,
                player.posZ,
                player.onGround);

        AquaStrike.eventBus.post(event);

        // Write modified values back so the packet built by vanilla uses them
        player.rotationYaw   = event.getYaw();
        player.rotationPitch = event.getPitch();
        if (event.isOnGroundModified()) {
            // The mixin injects before the method reads onGround, so we reflect-write it
            try {
                java.lang.reflect.Field f = EntityPlayerSP.class.getSuperclass()
                        .getDeclaredField("onGround");
                f.setAccessible(true);
                f.set(player, event.getOnGround());
            } catch (Exception ignored) {}
        }
    }

    @Inject(method = "onUpdateWalkingPlayer", at = @At("RETURN"))
    private void onUpdatePost(CallbackInfo ci) {
        EntityPlayerSP player = (EntityPlayerSP)(Object) this;
        EventMotion event = new EventMotion(
                EventMotion.Type.POST,
                player.rotationYaw,
                player.rotationPitch,
                player.posX,
                player.posY,
                player.posZ,
                player.onGround);

        AquaStrike.eventBus.post(event);

        // POST lets silent-aura restore the client-side view
        player.rotationYaw   = event.getYaw();
        player.rotationPitch = event.getPitch();
    }
}
