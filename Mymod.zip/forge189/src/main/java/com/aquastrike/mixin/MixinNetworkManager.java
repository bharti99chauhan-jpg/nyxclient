package com.aquastrike.mixin;

import com.aquastrike.AquaStrike;
import com.aquastrike.event.events.EventSendPacket;
import com.aquastrike.module.modules.combat.Velocity;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.Packet;
import net.minecraft.network.play.server.S12PacketEntityVelocity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(NetworkManager.class)
public class MixinNetworkManager {

    /** Fire EventSendPacket for every outgoing packet, allow cancellation. */
    @Inject(method = "sendPacket(Lnet/minecraft/network/Packet;)V",
            at = @At("HEAD"), cancellable = true)
    private void onSendPacket(Packet<?> packet, CallbackInfo ci) {
        EventSendPacket event = new EventSendPacket(packet);
        AquaStrike.eventBus.post(event);
        if (event.isCancelled()) ci.cancel();
    }

    /**
     * Intercept the inbound S12 velocity packet and reduce it
     * according to the Velocity module's multipliers.
     * processPacket dispatches to the client handler on the main thread.
     */
    @Inject(method = "processPacket(Lnet/minecraft/network/Packet;Lnet/minecraft/util/IThreadListener;)V",
            at = @At("HEAD"))
    private static void onProcessPacket(Packet<?> packet,
                                        net.minecraft.util.IThreadListener listener,
                                        CallbackInfo ci) {
        if (!(packet instanceof S12PacketEntityVelocity)) return;
        if (AquaStrike.moduleManager == null) return;
        Velocity vel = AquaStrike.moduleManager.get(Velocity.class);
        if (vel == null || !vel.isEnabled()) return;

        S12PacketEntityVelocity p = (S12PacketEntityVelocity) packet;
        try {
            java.lang.reflect.Field fx = S12PacketEntityVelocity.class.getDeclaredField("motionX");
            java.lang.reflect.Field fy = S12PacketEntityVelocity.class.getDeclaredField("motionY");
            java.lang.reflect.Field fz = S12PacketEntityVelocity.class.getDeclaredField("motionZ");
            fx.setAccessible(true); fy.setAccessible(true); fz.setAccessible(true);
            fx.setInt(p, (int)(fx.getInt(p) * vel.getHorizontalMultiplier()));
            fy.setInt(p, (int)(fy.getInt(p) * vel.getVerticalMultiplier()));
            fz.setInt(p, (int)(fz.getInt(p) * vel.getHorizontalMultiplier()));
        } catch (Exception ignored) {}
    }
}
