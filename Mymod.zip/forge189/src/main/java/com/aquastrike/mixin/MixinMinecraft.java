package com.aquastrike.mixin;

import com.aquastrike.AquaStrike;
import com.aquastrike.gui.ClickGUI;
import net.minecraft.client.Minecraft;
import org.lwjgl.input.Keyboard;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Minecraft.class)
public class MixinMinecraft {

    /** Open ClickGUI on RSHIFT. Toggle individual modules via keybinds from ModuleManager. */
    @Inject(method = "runTick", at = @At("RETURN"))
    private void onTick(CallbackInfo ci) {
        Minecraft mc = (Minecraft)(Object) this;
        if (Keyboard.isKeyDown(Keyboard.KEY_RSHIFT)
                && Keyboard.getEventKeyState()
                && mc.currentScreen == null) {
            mc.displayGuiScreen(new ClickGUI());
        }
    }
}
