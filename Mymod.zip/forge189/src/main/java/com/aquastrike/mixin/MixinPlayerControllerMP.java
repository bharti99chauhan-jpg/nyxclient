package com.aquastrike.mixin;

import com.aquastrike.AquaStrike;
import com.aquastrike.module.modules.combat.Reach;
import com.aquastrike.module.modules.player.FastPlace;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PlayerControllerMP.class)
public class MixinPlayerControllerMP {

    /**
     * Shadow the right-click delay field so Mixin's annotation processor
     * generates a refmap entry that correctly maps "rightClickDelay" →
     * SRG "field_78774_b" at build time. This is the ONLY correct way —
     * getDeclaredField("rightClickDelay") is a string literal that ForgeGradle
     * never touches, so it always throws NoSuchFieldException in production
     * and FastPlace silently does nothing.
     */
    @Shadow
    private int rightClickDelay;

    /** Extend block-break reach. */
    @ModifyVariable(method = "getBlockReachDistance", at = @At("RETURN"), index = 0)
    private float modifyBlockReach(float original) {
        Reach reach = AquaStrike.moduleManager.get(Reach.class);
        if (reach != null && reach.isEnabled()) return reach.getBlockReach();
        return original;
    }

    /**
     * FastPlace — zero the right-click delay every controller update.
     * updateController runs once per tick before motion, so this takes
     * effect immediately on the same tick FastPlace is enabled.
     */
    @Inject(method = "updateController", at = @At("HEAD"))
    private void onUpdate(CallbackInfo ci) {
        FastPlace fp = AquaStrike.moduleManager.get(FastPlace.class);
        if (fp != null && fp.isEnabled()) {
            rightClickDelay = 0;
        }
    }
}
