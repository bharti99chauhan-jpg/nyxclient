package com.aquastrike.module.setting;

import java.util.Arrays;
import java.util.List;

public class ListSetting extends Setting<String> {
    private final List<String> options;

    public ListSetting(String name, String def, String... options) {
        super(name, def);
        this.options = Arrays.asList(options);
    }

    public List<String> getOptions() { return options; }

    public void cycle() {
        int idx = (options.indexOf(value) + 1) % options.size();
        value = options.get(idx);
    }

    public boolean is(String opt) { return value.equalsIgnoreCase(opt); }
}
