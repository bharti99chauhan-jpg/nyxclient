package com.aquastrike.module.modules.misc;

import com.aquastrike.module.Category;
import com.aquastrike.module.Module;
import com.aquastrike.module.setting.NumberSetting;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class Timer extends Module {

    private final NumberSetting speed = add(new NumberSetting("Speed", 2.0, 0.1, 10.0, 0.1));

    public Timer() { super("Timer", Category.MISC); }

    @Override
    protected void onEnable() {
        super.onEnable();
        applySpeed();
    }

    @Override
    protected void onDisable() {
        super.onDisable();
        try {
            net.minecraft.client.timer.Timer timer = getTimer();
            if (timer != null) timer.timerSpeed = 1.0f;
        } catch (Exception ignored) {}
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.START) return;
        applySpeed();
    }

    private void applySpeed() {
        try {
            net.minecraft.client.timer.Timer timer = getTimer();
            if (timer != null) timer.timerSpeed = speed.getFloat();
        } catch (Exception ignored) {}
    }

    private net.minecraft.client.timer.Timer getTimer() {
        try {
            java.lang.reflect.Field f =
                    net.minecraft.client.Minecraft.class.getDeclaredField("timer");
            f.setAccessible(true);
            return (net.minecraft.client.timer.Timer) f.get(mc);
        } catch (Exception e) {
            return null;
        }
    }
}
