package com.aquastrike.module.modules.combat;

import com.aquastrike.AquaStrike;
import com.aquastrike.event.EventTarget;
import com.aquastrike.event.events.EventMotion;
import com.aquastrike.module.Category;
import com.aquastrike.module.Module;
import com.aquastrike.module.setting.BoolSetting;
import com.aquastrike.module.setting.NumberSetting;
import com.aquastrike.utils.RotationUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.item.*;
import org.lwjgl.input.Mouse;

/**
 * AutoClicker — Gaussian CPS distribution, hold-to-click mode.
 *
 * Key fix: added HoldLeft / HoldRight bool settings.
 *   HoldLeft ON  → left-click fires ONLY while LMB is physically held down.
 *   HoldLeft OFF → left-click fires automatically at the configured CPS.
 * Without this, enabling the module started clicking immediately with no way
 * to stop it except disabling the module.
 *
 * CPS distribution: Box-Muller Gaussian centered at (min+max)/2 with
 * σ = range/6 so ±3σ spans the full [min,max] range (essentially no
 * outliers). Every scheduled click re-draws independently.
 */
public class AutoClicker extends Module {

    // Left click settings
    private final BoolSetting leftClick   = add(new BoolSetting("LeftClick",    true));
    private final BoolSetting holdLeft    = add(new BoolSetting("HoldLeft",     true));
    private final NumberSetting leftMin   = add(new NumberSetting("L-MinCPS",   8,  1, 20, 1));
    private final NumberSetting leftMax   = add(new NumberSetting("L-MaxCPS",  12,  1, 20, 1));

    // Right click settings
    private final BoolSetting rightClick  = add(new BoolSetting("RightClick",   false));
    private final BoolSetting holdRight   = add(new BoolSetting("HoldRight",    true));
    private final NumberSetting rightMin  = add(new NumberSetting("R-MinCPS",   6,  1, 20, 1));
    private final NumberSetting rightMax  = add(new NumberSetting("R-MaxCPS",  10,  1, 20, 1));

    // Filters
    private final BoolSetting weaponOnly  = add(new BoolSetting("WeaponOnly",   false));
    private final BoolSetting invCheck    = add(new BoolSetting("InvCheck",     true));
    private final BoolSetting blockBreak  = add(new BoolSetting("BlockBreak",   false));
    private final BoolSetting onlyOnTarget= add(new BoolSetting("OnlyOnTarget", false));

    private long nextLeftClick  = 0;
    private long nextRightClick = 0;

    public AutoClicker() { super("AutoClicker", Category.COMBAT); }

    @EventTarget
    public void onMotion(EventMotion event) {
        if (!event.isPre()) return;
        if (mc.theWorld == null || mc.thePlayer == null) return;
        if (mc.thePlayer.isUsingItem()) return;

        // Inventory guard — don't click if any inventory screen is open
        if (invCheck.isEnabled() && mc.currentScreen != null) return;

        long now = System.currentTimeMillis();

        // ── Left click ────────────────────────────────────────────────────
        if (leftClick.isEnabled()) {
            // HoldLeft: only click when the actual LMB is physically held
            boolean lmbHeld = Mouse.isButtonDown(0);
            if (holdLeft.isEnabled() && !lmbHeld) {
                nextLeftClick = 0; // reset schedule so it fires immediately when held again
            } else if (!holdLeft.isEnabled() || lmbHeld) {
                if (now >= nextLeftClick && shouldClickLeft()) {
                    doLeftClick();
                    scheduleLeft();
                }
            }
        }

        // ── Right click ───────────────────────────────────────────────────
        if (rightClick.isEnabled()) {
            boolean rmbHeld = Mouse.isButtonDown(1);
            if (holdRight.isEnabled() && !rmbHeld) {
                nextRightClick = 0;
            } else if (!holdRight.isEnabled() || rmbHeld) {
                if (now >= nextRightClick) {
                    doRightClick();
                    scheduleRight();
                }
            }
        }
    }

    // ── Click execution ───────────────────────────────────────────────────

    private void doLeftClick() {
        // Simulate a press + release via KeyBinding so it goes through Forge
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindAttack.getKeyCode(), true);
        KeyBinding.onTick(mc.gameSettings.keyBindAttack.getKeyCode());
    }

    private void doRightClick() {
        // Block-break guard: don't interfere while mining
        if (!blockBreak.isEnabled() && mc.playerController.isHittingBlock()) return;
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindUseItem.getKeyCode(), true);
        KeyBinding.onTick(mc.gameSettings.keyBindUseItem.getKeyCode());
    }

    // ── Scheduling ────────────────────────────────────────────────────────

    private void scheduleLeft() {
        nextLeftClick = System.currentTimeMillis()
                + (long) gaussianMs(leftMin.getValue(), leftMax.getValue());
    }

    private void scheduleRight() {
        nextRightClick = System.currentTimeMillis()
                + (long) gaussianMs(rightMin.getValue(), rightMax.getValue());
    }

    // ── Gaussian CPS → ms delay ───────────────────────────────────────────
    // mean = (min+max)/2, σ = range/6 (±3σ fills range, nearly no outliers)

    private double gaussianMs(double minCPS, double maxCPS) {
        double meanCPS = (minCPS + maxCPS) * 0.5;
        double sigma   = (maxCPS - minCPS) / 6.0 + 0.1; // small floor to avoid div-by-zero
        double cps     = RotationUtils.gaussian((float) meanCPS, (float) sigma);
        cps = Math.max(1.0, Math.min(20.0, cps));
        return 1000.0 / cps;
    }

    // ── Left-click eligibility ────────────────────────────────────────────

    private boolean shouldClickLeft() {
        // WeaponOnly: skip if holding a non-weapon
        if (weaponOnly.isEnabled() && !isHoldingWeapon()) return false;
        // OnlyOnTarget: skip if KillAura has no target locked
        if (onlyOnTarget.isEnabled()) {
            KillAura ka = AquaStrike.moduleManager.get(KillAura.class);
            if (ka == null || !ka.isEnabled() || ka.getCurrentTarget() == null) return false;
        }
        return true;
    }

    private boolean isHoldingWeapon() {
        ItemStack stack = mc.thePlayer.getHeldItem();
        if (stack == null) return false;
        Item item = stack.getItem();
        return item instanceof ItemSword
                || item instanceof ItemAxe
                || item instanceof ItemPickaxe
                || item instanceof ItemSpade
                || item instanceof ItemHoe
                || item instanceof ItemBow;
    }

    @Override
    public String getSuffix() {
        double mean = (leftMin.getValue() + leftMax.getValue()) * 0.5;
        return String.format("%.0f", mean) + " cps";
    }
}
