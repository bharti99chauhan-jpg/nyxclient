package com.aquastrike.module.modules.misc;

import com.aquastrike.module.Category;
import com.aquastrike.module.Module;
import com.aquastrike.module.setting.NumberSetting;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class AntiAFK extends Module {

    private final NumberSetting interval = add(new NumberSetting("Interval", 100, 20, 600, 10));
    private int tick = 0;

    public AntiAFK() { super("AntiAFK", Category.MISC); }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent event) {
        if (!isEnabled() || event.phase != TickEvent.Phase.START) return;
        if (mc.thePlayer == null) return;
        tick++;
        if (tick >= interval.getInt()) {
            // Send a small look rotation to prevent kick
            mc.thePlayer.rotationYaw += 1f;
            tick = 0;
        }
    }
}
