package com.aquastrike.module.modules.movement;

import com.aquastrike.event.EventTarget;
import com.aquastrike.event.events.EventSendPacket;
import com.aquastrike.module.Category;
import com.aquastrike.module.Module;
import net.minecraft.network.play.client.C0BPacketEntityAction;

public class NoSlow extends Module {
    public NoSlow() { super("NoSlow", Category.MOVEMENT); }

    @EventTarget
    public void onPacket(EventSendPacket event) {
        // Block STOP_SNEAKING and START_SNEAKING while blocking to prevent slow
        if (event.getPacket() instanceof C0BPacketEntityAction) {
            C0BPacketEntityAction p = (C0BPacketEntityAction) event.getPacket();
            if (p.getAction() == C0BPacketEntityAction.Action.START_EATING_BLOCK
             || p.getAction() == C0BPacketEntityAction.Action.STOP_SNEAKING) {
                event.setCancelled(true);
            }
        }
    }
}
