package com.aquastrike.module;

public enum Category {
    COMBAT("Combat"),
    MOVEMENT("Movement"),
    RENDER("Render"),
    PLAYER("Player"),
    MISC("Misc");

    public final String display;
    Category(String d) { this.display = d; }
}
