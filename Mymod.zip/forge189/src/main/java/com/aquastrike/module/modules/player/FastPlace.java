package com.aquastrike.module.modules.player;

import com.aquastrike.module.Category;
import com.aquastrike.module.Module;

/**
 * FastPlace — removes the right-click cooldown (rightClickDelay → 0 each tick).
 *
 * Implementation is in MixinPlayerControllerMP via @Shadow rightClickDelay.
 * The field is zeroed every updateController() call when this module is enabled.
 *
 * Previous implementation used getDeclaredField("rightClickDelay") which is a
 * string literal — ForgeGradle never reobfuscates string literals, so the field
 * lookup always threw NoSuchFieldException in production and was silently eaten.
 * @Shadow generates a correct refmap entry at compile time.
 */
public class FastPlace extends Module {
    public FastPlace() { super("FastPlace", Category.PLAYER); }
}
