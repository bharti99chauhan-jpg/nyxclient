package com.aquastrike.module.modules.render;

import com.aquastrike.module.Category;
import com.aquastrike.module.Module;

public class FullBright extends Module {

    private float savedGamma = 1f;

    public FullBright() { super("FullBright", Category.RENDER); }

    @Override
    protected void onEnable() {
        super.onEnable();
        savedGamma = mc.gameSettings.gammaSetting;
        mc.gameSettings.gammaSetting = 100f;
    }

    @Override
    protected void onDisable() {
        super.onDisable();
        mc.gameSettings.gammaSetting = savedGamma;
    }
}
