package com.aquastrike.module.modules.movement;

import com.aquastrike.event.EventTarget;
import com.aquastrike.event.events.EventMotion;
import com.aquastrike.module.Category;
import com.aquastrike.module.Module;
import com.aquastrike.module.setting.BoolSetting;
import com.aquastrike.module.setting.ListSetting;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.C0APacketAnimation;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;

public class Scaffold extends Module {

    private final BoolSetting tower      = add(new BoolSetting("Tower",     false));
    private final BoolSetting safeWalk   = add(new BoolSetting("SafeWalk",  true));
    private final BoolSetting sprint     = add(new BoolSetting("Sprint",    true));
    private final ListSetting delay      = add(new ListSetting("Delay", "None", "None", "Legit"));

    public Scaffold() { super("Scaffold", Category.MOVEMENT); }

    @EventTarget
    public void onMotion(EventMotion event) {
        if (!event.isPre()) return;
        if (mc.theWorld == null || mc.thePlayer == null) return;

        // Safe-walk: prevent falling off edge
        if (safeWalk.isEnabled()) {
            mc.thePlayer.setSneaking(true);
        }
        if (sprint.isEnabled() && mc.thePlayer.movementInput.moveForward > 0) {
            mc.thePlayer.setSprinting(true);
        }

        // Tower: jump continuously while holding jump
        if (tower.isEnabled() && mc.thePlayer.onGround
                && mc.gameSettings.keyBindJump.isKeyDown()) {
            mc.thePlayer.motionY = 0.42;
        }

        // Find a valid block in hot-bar
        int slot = findBlockSlot();
        if (slot == -1) return;

        // Place block below player
        BlockPos below = new BlockPos(mc.thePlayer).down();
        if (mc.theWorld.getBlockState(below).getBlock() != Blocks.air) return;

        // Try placing on each face of blocks adjacent to below
        BlockPos[] candidates = {
            below.down(), below.north(), below.south(), below.east(), below.west()
        };

        for (BlockPos candidate : candidates) {
            Block b = mc.theWorld.getBlockState(candidate).getBlock();
            if (b == Blocks.air || b.getMaterial() == Material.water
                    || b.getMaterial() == Material.lava) continue;

            // Determine which face of `candidate` faces `below`
            EnumFacing face = getFacing(candidate, below);
            if (face == null) continue;

            // Rotate silently to face the place position
            double cx = candidate.getX() + 0.5 + face.getFrontOffsetX() * 0.5;
            double cy = candidate.getY() + 0.5 + face.getFrontOffsetY() * 0.5;
            double cz = candidate.getZ() + 0.5 + face.getFrontOffsetZ() * 0.5;

            int prevSlot = mc.thePlayer.inventory.currentItem;
            mc.thePlayer.inventory.currentItem = slot;

            mc.getNetHandler().addToSendQueue(new C0APacketAnimation());
            mc.getNetHandler().addToSendQueue(new C08PacketPlayerBlockPlacement(
                    candidate, face.getIndex(),
                    mc.thePlayer.inventory.getStackInSlot(slot),
                    0.5f, 0.5f, 0.5f));

            mc.theWorld.playAuxSFXAtEntity(null, 1001, below, 0);
            mc.thePlayer.inventory.currentItem = prevSlot;
            break;
        }
    }

    @Override
    protected void onDisable() {
        super.onDisable();
        mc.thePlayer.setSneaking(false);
    }

    private int findBlockSlot() {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.thePlayer.inventory.getStackInSlot(i);
            if (stack != null && stack.getItem() instanceof ItemBlock) {
                ItemBlock ib = (ItemBlock) stack.getItem();
                if (ib.getBlock() != Blocks.air) return i;
            }
        }
        return -1;
    }

    private EnumFacing getFacing(BlockPos from, BlockPos to) {
        int dx = to.getX() - from.getX();
        int dy = to.getY() - from.getY();
        int dz = to.getZ() - from.getZ();
        for (EnumFacing f : EnumFacing.values()) {
            if (f.getFrontOffsetX() == dx
                    && f.getFrontOffsetY() == dy
                    && f.getFrontOffsetZ() == dz) return f;
        }
        return null;
    }
}
