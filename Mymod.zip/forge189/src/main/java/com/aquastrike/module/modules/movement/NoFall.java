package com.aquastrike.module.modules.movement;

import com.aquastrike.event.EventTarget;
import com.aquastrike.event.events.EventMotion;
import com.aquastrike.module.Category;
import com.aquastrike.module.Module;

public class NoFall extends Module {

    public NoFall() { super("NoFall", Category.MOVEMENT); }

    @EventTarget
    public void onMotion(EventMotion event) {
        if (!event.isPre()) return;
        // Send onGround=true to server when falling to cancel fall damage
        if (mc.thePlayer.fallDistance > 2f) {
            event.setOnGround(true);
        }
    }
}
