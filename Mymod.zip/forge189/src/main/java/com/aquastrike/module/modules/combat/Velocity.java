package com.aquastrike.module.modules.combat;

import com.aquastrike.event.EventTarget;
import com.aquastrike.event.events.EventSendPacket;
import com.aquastrike.module.Category;
import com.aquastrike.module.Module;
import com.aquastrike.module.setting.NumberSetting;
import net.minecraft.network.play.server.S12PacketEntityVelocity;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.network.FMLNetworkEvent;

public class Velocity extends Module {

    private final NumberSetting horizontal = add(new NumberSetting("Horizontal", 0, 0, 100, 1));
    private final NumberSetting vertical   = add(new NumberSetting("Vertical",   0, 0, 100, 1));

    public Velocity() { super("Velocity", Category.COMBAT); }

    // We hook the packet in MixinNetworkManager via EventSendPacket.
    // Here we store the reduction multipliers; the mixin calls the static accessor.

    @EventTarget
    public void onPacket(EventSendPacket event) {
        // Velocity cancel is handled via S12 packet in the mixin side.
        // This module's settings drive the multipliers used there.
    }

    public double getHorizontalMultiplier() { return horizontal.getValue() / 100.0; }
    public double getVerticalMultiplier()   { return vertical.getValue()   / 100.0; }
}
