package com.aquastrike.module.modules.movement;

import com.aquastrike.event.EventTarget;
import com.aquastrike.event.events.EventMotion;
import com.aquastrike.module.Category;
import com.aquastrike.module.Module;
import com.aquastrike.module.setting.ListSetting;
import com.aquastrike.module.setting.NumberSetting;

public class Speed extends Module {

    private final ListSetting   mode  = add(new ListSetting("Mode", "Strafe", "Strafe", "BHop", "Vanilla"));
    private final NumberSetting speed = add(new NumberSetting("Speed", 1.3, 1.0, 5.0, 0.1));

    public Speed() { super("Speed", Category.MOVEMENT); }

    @EventTarget
    public void onMotion(EventMotion event) {
        if (!event.isPre()) return;
        if (mc.thePlayer == null || mc.thePlayer.onGround) {
            if (mode.is("BHop") || mode.is("Strafe")) {
                mc.thePlayer.jump();
            }
        }
        if (!mc.thePlayer.onGround) {
            double yaw = Math.toRadians(mc.thePlayer.rotationYaw);
            mc.thePlayer.motionX = -Math.sin(yaw) * speed.getValue();
            mc.thePlayer.motionZ =  Math.cos(yaw) * speed.getValue();
        }
    }
}
