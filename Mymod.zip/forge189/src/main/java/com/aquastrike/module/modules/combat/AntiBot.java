package com.aquastrike.module.modules.combat;

import com.aquastrike.module.Category;
import com.aquastrike.module.Module;
import com.aquastrike.module.setting.BoolSetting;

public class AntiBot extends Module {

    private final BoolSetting newTick  = add(new BoolSetting("NewTick",  true));
    private final BoolSetting invalid  = add(new BoolSetting("Invalid",  true));
    private final BoolSetting ground   = add(new BoolSetting("Ground",   false));

    public AntiBot() { super("AntiBot", Category.COMBAT); }
    // Filtering is done in EntityUtils.canTarget() and KillAura's pre-filter
}
