package com.aquastrike.module.modules.movement;

import com.aquastrike.event.EventTarget;
import com.aquastrike.event.events.EventMotion;
import com.aquastrike.module.Category;
import com.aquastrike.module.Module;
import com.aquastrike.module.setting.ListSetting;
import com.aquastrike.module.setting.NumberSetting;

public class Fly extends Module {

    private final ListSetting   mode  = add(new ListSetting("Mode", "Vanilla", "Vanilla", "Creative"));
    private final NumberSetting speed = add(new NumberSetting("Speed", 1.0, 0.1, 5.0, 0.1));

    public Fly() { super("Fly", Category.MOVEMENT); }

    @Override
    protected void onEnable() {
        super.onEnable();
        mc.thePlayer.capabilities.isFlying = true;
        mc.thePlayer.capabilities.flySpeed = speed.getFloat() * 0.05f;
    }

    @Override
    protected void onDisable() {
        super.onDisable();
        mc.thePlayer.capabilities.isFlying = false;
    }

    @EventTarget
    public void onMotion(EventMotion event) {
        if (!event.isPre()) return;
        mc.thePlayer.capabilities.flySpeed = speed.getFloat() * 0.05f;
        mc.thePlayer.motionY = 0;
        if (mc.gameSettings.keyBindJump.isKeyDown())   mc.thePlayer.motionY =  speed.getValue();
        if (mc.gameSettings.keyBindSneak.isKeyDown())  mc.thePlayer.motionY = -speed.getValue();
    }
}
