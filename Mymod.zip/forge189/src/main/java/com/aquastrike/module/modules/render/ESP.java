package com.aquastrike.module.modules.render;

import com.aquastrike.module.Category;
import com.aquastrike.module.Module;
import com.aquastrike.module.setting.BoolSetting;
import com.aquastrike.module.setting.ListSetting;
import com.aquastrike.module.setting.NumberSetting;
import com.aquastrike.utils.RenderUtils;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.awt.*;

public class ESP extends Module {

    private final ListSetting   mode    = add(new ListSetting("Mode", "Box", "Box", "Outline"));
    private final BoolSetting   players = add(new BoolSetting("Players", true));
    private final BoolSetting   mobs    = add(new BoolSetting("Mobs",    false));
    private final BoolSetting   filled  = add(new BoolSetting("Filled",  false));
    private final NumberSetting r       = add(new NumberSetting("R", 255, 0, 255, 1));
    private final NumberSetting g       = add(new NumberSetting("G", 50,  0, 255, 1));
    private final NumberSetting b       = add(new NumberSetting("B", 50,  0, 255, 1));
    private final NumberSetting alpha   = add(new NumberSetting("Alpha", 180, 0, 255, 1));

    public ESP() { super("ESP", Category.RENDER); }

    @SubscribeEvent
    public void onRender(RenderWorldLastEvent event) {
        if (!isEnabled()) return;
        Color color = new Color(r.getInt(), g.getInt(), b.getInt(), alpha.getInt());
        for (Object obj : mc.theWorld.loadedEntityList) {
            if (!(obj instanceof EntityLivingBase)) continue;
            EntityLivingBase e = (EntityLivingBase) obj;
            if (e == mc.thePlayer) continue;
            if (players.isEnabled() && e instanceof EntityPlayer) {
                RenderUtils.drawEntityBox(e, color, filled.isEnabled());
            } else if (mobs.isEnabled() && !(e instanceof EntityPlayer)) {
                RenderUtils.drawEntityBox(e, color, filled.isEnabled());
            }
        }
    }
}
