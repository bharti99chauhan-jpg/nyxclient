package com.aquastrike.module.modules.combat;

import com.aquastrike.module.Category;
import com.aquastrike.module.Module;
import com.aquastrike.module.setting.NumberSetting;

public class Reach extends Module {

    private final NumberSetting reach     = add(new NumberSetting("Reach",     3.5, 3.0, 6.0, 0.1));
    private final NumberSetting blockReach= add(new NumberSetting("BlockReach",4.5, 4.0, 6.0, 0.1));

    public Reach() { super("Reach", Category.COMBAT); }

    public float getReach()      { return reach.getFloat();      }
    public float getBlockReach() { return blockReach.getFloat(); }
    // Applied in MixinPlayerControllerMP
}
