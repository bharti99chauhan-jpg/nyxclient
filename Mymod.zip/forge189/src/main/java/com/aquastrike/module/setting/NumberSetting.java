package com.aquastrike.module.setting;

public class NumberSetting extends Setting<Double> {
    private final double min, max, increment;

    public NumberSetting(String name, double def, double min, double max, double increment) {
        super(name, def);
        this.min = min; this.max = max; this.increment = increment;
    }

    public double getMin()       { return min;       }
    public double getMax()       { return max;       }
    public double getIncrement() { return increment; }
    public float  getFloat()     { return value.floatValue(); }
    public int    getInt()       { return value.intValue();   }

    @Override public void setValue(Double v) {
        this.value = Math.min(max, Math.max(min, v));
    }
}
