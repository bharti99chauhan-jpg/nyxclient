package com.aquastrike.module.modules.render;

import com.aquastrike.module.Category;
import com.aquastrike.module.Module;
import com.aquastrike.module.setting.BoolSetting;
import com.aquastrike.module.setting.NumberSetting;
import com.aquastrike.utils.RenderUtils;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.awt.*;

public class Tracers extends Module {

    private final BoolSetting   players = add(new BoolSetting("Players", true));
    private final BoolSetting   mobs    = add(new BoolSetting("Mobs",    false));
    private final NumberSetting r       = add(new NumberSetting("R", 255, 0, 255, 1));
    private final NumberSetting g       = add(new NumberSetting("G", 255, 0, 255, 1));
    private final NumberSetting b       = add(new NumberSetting("B", 50,  0, 255, 1));

    public Tracers() { super("Tracers", Category.RENDER); }

    @SubscribeEvent
    public void onRender(RenderWorldLastEvent event) {
        if (!isEnabled()) return;
        Color color = new Color(r.getInt(), g.getInt(), b.getInt(), 200);
        for (Object obj : mc.theWorld.loadedEntityList) {
            if (obj == mc.thePlayer) continue;
            if (players.isEnabled() && obj instanceof EntityPlayer) {
                RenderUtils.drawTracer((EntityPlayer) obj, color);
            }
        }
    }
}
