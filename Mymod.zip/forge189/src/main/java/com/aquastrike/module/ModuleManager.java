package com.aquastrike.module;

import com.aquastrike.AquaStrike;
import com.aquastrike.module.modules.combat.*;
import com.aquastrike.module.modules.misc.*;
import com.aquastrike.module.modules.movement.*;
import com.aquastrike.module.modules.player.*;
import com.aquastrike.module.modules.render.*;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {

    public final List<Module> modules = new ArrayList<>();

    public ModuleManager() {
        // Combat
        modules.add(new KillAura());
        modules.add(new AutoClicker());
        modules.add(new AimAssist());
        modules.add(new Velocity());
        modules.add(new Criticals());
        modules.add(new AutoBlock());
        modules.add(new AntiBot());
        modules.add(new Reach());

        // Movement
        modules.add(new Sprint());
        modules.add(new Speed());
        modules.add(new Fly());
        modules.add(new NoFall());
        modules.add(new BHop());
        modules.add(new SafeWalk());
        modules.add(new NoSlow());
        modules.add(new Scaffold());

        // Render
        modules.add(new ESP());
        modules.add(new FullBright());
        modules.add(new Tracers());
        modules.add(new ArmorHUD());

        // Player
        modules.add(new FastPlace());
        modules.add(new NoSwing());
        modules.add(new FastEat());

        // Misc
        modules.add(new AntiAFK());
        modules.add(new Blink());
        modules.add(new Disabler());
        modules.add(new Timer());
    }

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.START) return;
        for (Module m : modules) {
            if (m.isEnabled()) {
                AquaStrike.eventBus.post(e);
            }
        }
    }

    @SubscribeEvent
    public void onKeyInput(InputEvent.KeyInputEvent e) {
        for (Module m : modules) {
            if (m.getKeyBind() != Keyboard.KEY_NONE
                    && Keyboard.isKeyDown(m.getKeyBind())
                    && Keyboard.getEventKeyState()) {
                m.toggle();
            }
        }
    }

    public Module getModule(Class<? extends Module> clazz) {
        for (Module m : modules) {
            if (m.getClass() == clazz) return m;
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    public <T extends Module> T get(Class<T> clazz) {
        return (T) getModule(clazz);
    }

    public List<Module> getModulesByCategory(Category cat) {
        List<Module> list = new ArrayList<>();
        for (Module m : modules) if (m.getCategory() == cat) list.add(m);
        return list;
    }
}
