package com.aquastrike.module.modules.combat;

import com.aquastrike.AquaStrike;
import com.aquastrike.event.EventTarget;
import com.aquastrike.event.events.EventMotion;
import com.aquastrike.module.Category;
import com.aquastrike.module.Module;
import com.aquastrike.module.setting.ListSetting;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;

public class AutoBlock extends Module {

    private final ListSetting mode = add(new ListSetting("Mode", "Vanilla", "Vanilla", "Fake"));

    public AutoBlock() { super("AutoBlock", Category.COMBAT); }

    @EventTarget
    public void onMotion(EventMotion event) {
        if (!event.isPre()) return;
        KillAura ka = AquaStrike.moduleManager.get(KillAura.class);
        if (ka == null || !ka.isEnabled() || ka.getTarget() == null) return;

        if (mode.is("Vanilla")) {
            // Send right-click on block to start blocking (1.8 mechanic)
            mc.getNetHandler().addToSendQueue(
                    new C08PacketPlayerBlockPlacement(BlockPos.ORIGIN, 255,
                            mc.thePlayer.inventory.getCurrentItem(), 0, 0, 0));
        }
        // "Fake" mode — only visual; handled in renderer
    }
}
