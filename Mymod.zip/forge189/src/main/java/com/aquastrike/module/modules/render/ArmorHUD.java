package com.aquastrike.module.modules.render;

import com.aquastrike.module.Category;
import com.aquastrike.module.Module;
import com.aquastrike.module.setting.NumberSetting;
import net.minecraft.client.gui.Gui;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class ArmorHUD extends Module {

    private final NumberSetting x = add(new NumberSetting("X", 2, 0, 500, 1));
    private final NumberSetting y = add(new NumberSetting("Y", 2, 0, 300, 1));

    public ArmorHUD() { super("ArmorHUD", Category.RENDER); }

    @SubscribeEvent
    public void onOverlay(RenderGameOverlayEvent.Post event) {
        if (!isEnabled()) return;
        if (event.type != RenderGameOverlayEvent.ElementType.ALL) return;

        int px = x.getInt(), py = y.getInt();
        ItemStack[] armor = mc.thePlayer.inventory.armorInventory;

        // Draw from helmet (3) down to boots (0)
        for (int i = 3; i >= 0; i--) {
            ItemStack stack = armor[i];
            if (stack == null) continue;
            mc.getRenderItem().renderItemIntoGUI(stack, px, py);
            if (stack.getItem() instanceof ItemArmor) {
                int durPct = (int) (100.0 * stack.getItemDamage() / stack.getMaxDamage());
                mc.fontRendererObj.drawStringWithShadow(
                        durPct + "%", px + 18, py + 5, getDurColor(durPct));
            }
            py += 20;
        }
    }

    private int getDurColor(int pct) {
        if (pct < 25)  return 0xFFFF4444;
        if (pct < 60)  return 0xFFFFAA00;
        return 0xFF55FF55;
    }
}
