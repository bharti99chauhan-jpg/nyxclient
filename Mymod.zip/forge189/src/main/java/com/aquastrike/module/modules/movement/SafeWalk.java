package com.aquastrike.module.modules.movement;

import com.aquastrike.event.EventTarget;
import com.aquastrike.event.events.EventMotion;
import com.aquastrike.module.Category;
import com.aquastrike.module.Module;

public class SafeWalk extends Module {
    public SafeWalk() { super("SafeWalk", Category.MOVEMENT); }

    @EventTarget
    public void onMotion(EventMotion event) {
        if (!event.isPre()) return;
        // Sneak at edges to avoid falling — set sneak flag
        mc.thePlayer.setSneaking(true);
    }

    @Override
    protected void onDisable() {
        super.onDisable();
        mc.thePlayer.setSneaking(false);
    }
}
