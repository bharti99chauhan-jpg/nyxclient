package com.aquastrike.module.modules.combat;

import com.aquastrike.event.EventTarget;
import com.aquastrike.event.events.EventMotion;
import com.aquastrike.module.Category;
import com.aquastrike.module.Module;
import com.aquastrike.module.setting.BoolSetting;
import com.aquastrike.module.setting.NumberSetting;
import com.aquastrike.utils.EntityUtils;
import com.aquastrike.utils.RotationUtils;
import net.minecraft.entity.EntityLivingBase;

import java.util.List;

public class AimAssist extends Module {

    private final NumberSetting range   = add(new NumberSetting("Range",   5.0, 1.0, 10.0, 0.1));
    private final NumberSetting fov     = add(new NumberSetting("FOV",     60,  10,  360,  5));
    private final NumberSetting speed   = add(new NumberSetting("Speed",   5.0, 0.5, 30.0, 0.5));
    private final BoolSetting   players = add(new BoolSetting("Players", true));
    private final BoolSetting   mobs    = add(new BoolSetting("Mobs",    false));

    public AimAssist() { super("AimAssist", Category.COMBAT); }

    @EventTarget
    public void onMotion(EventMotion event) {
        if (!event.isPre()) return;
        EntityUtils.TargetMode mode =
                players.isEnabled() ? EntityUtils.TargetMode.PLAYERS : EntityUtils.TargetMode.MOBS;

        List<EntityLivingBase> targets = EntityUtils.getTargets(range.getFloat(), mode, false, "angle");
        if (targets.isEmpty()) return;

        EntityLivingBase closest = null;
        float bestAngle = Float.MAX_VALUE;
        for (EntityLivingBase e : targets) {
            float[] rot  = RotationUtils.getRotationsToEntity(e);
            float   dist = RotationUtils.rotationDistance(
                    mc.thePlayer.rotationYaw, mc.thePlayer.rotationPitch, rot[0], rot[1]);
            if (dist < fov.getFloat() / 2f && dist < bestAngle) {
                bestAngle = dist;
                closest   = e;
            }
        }
        if (closest == null) return;

        float[] rot = RotationUtils.getRotationsToEntity(closest);
        float newYaw   = RotationUtils.smoothRotation(
                mc.thePlayer.rotationYaw,   rot[0], speed.getFloat());
        float newPitch = RotationUtils.smoothRotation(
                mc.thePlayer.rotationPitch, rot[1], speed.getFloat() * 0.6f);

        mc.thePlayer.rotationYaw   = newYaw;
        mc.thePlayer.rotationPitch = newPitch;
    }
}
