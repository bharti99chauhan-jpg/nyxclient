package com.aquastrike.module.modules.player;

import com.aquastrike.event.EventTarget;
import com.aquastrike.event.events.EventSendPacket;
import com.aquastrike.module.Category;
import com.aquastrike.module.Module;
import net.minecraft.network.play.client.C0APacketAnimation;

public class NoSwing extends Module {
    public NoSwing() { super("NoSwing", Category.PLAYER); }

    @EventTarget
    public void onPacket(EventSendPacket event) {
        if (event.getPacket() instanceof C0APacketAnimation) {
            event.setCancelled(true);
        }
    }
}
