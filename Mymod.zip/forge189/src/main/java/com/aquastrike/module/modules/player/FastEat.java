package com.aquastrike.module.modules.player;

import com.aquastrike.module.Category;
import com.aquastrike.module.Module;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class FastEat extends Module {
    public FastEat() { super("FastEat", Category.PLAYER); }

    // Handled in MixinPlayerControllerMP: itemUseCount is zeroed each tick
    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.START) return;
        if (!isEnabled()) return;
        if (mc.thePlayer != null && mc.thePlayer.isUsingItem()) {
            mc.thePlayer.itemInUseCount = 0;
        }
    }
}
