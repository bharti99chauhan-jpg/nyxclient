package com.aquastrike.module;

import com.aquastrike.AquaStrike;
import com.aquastrike.module.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraftforge.common.MinecraftForge;
import org.lwjgl.input.Keyboard;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {

    protected static final Minecraft mc = Minecraft.getMinecraft();

    private final String   name;
    private final Category category;
    private       int      keyBind;
    private       boolean  enabled;

    protected final List<Setting<?>> settings = new ArrayList<>();

    public Module(String name, Category category, int keyBind) {
        this.name     = name;
        this.category = category;
        this.keyBind  = keyBind;
    }

    public Module(String name, Category category) {
        this(name, category, Keyboard.KEY_NONE);
    }

    // ---- lifecycle ----------------------------------------------------------

    public final void toggle() {
        enabled = !enabled;
        if (enabled) onEnable();
        else         onDisable();
    }

    public final void enable()  { if (!enabled) toggle(); }
    public final void disable() { if (enabled)  toggle(); }

    protected void onEnable()  {
        AquaStrike.eventBus.register(this);
        MinecraftForge.EVENT_BUS.register(this);
    }
    protected void onDisable() {
        AquaStrike.eventBus.unregister(this);
        MinecraftForge.EVENT_BUS.unregister(this);
    }

    // ---- settings helpers ---------------------------------------------------

    protected <T extends Setting<?>> T add(T s) { settings.add(s); return s; }

    // ---- accessors ----------------------------------------------------------

    public String   getName()     { return name;     }
    public Category getCategory() { return category; }
    public int      getKeyBind()  { return keyBind;  }
    public boolean  isEnabled()   { return enabled;  }
    public List<Setting<?>> getSettings() { return settings; }

    public void setKeyBind(int key) { this.keyBind = key; }

    public String getSuffix() { return null; }
}
