package com.aquastrike.module.modules.movement;

import com.aquastrike.event.EventTarget;
import com.aquastrike.event.events.EventMotion;
import com.aquastrike.module.Category;
import com.aquastrike.module.Module;
import com.aquastrike.module.setting.ListSetting;

public class Sprint extends Module {

    private final ListSetting mode = add(new ListSetting("Mode", "Legit", "Legit", "Rage"));

    public Sprint() { super("Sprint", Category.MOVEMENT); }

    @EventTarget
    public void onMotion(EventMotion event) {
        if (!event.isPre()) return;
        if (mc.thePlayer == null) return;
        boolean moving = mc.thePlayer.movementInput.moveForward > 0;
        if (!moving && mode.is("Legit")) return;

        if (!mc.thePlayer.isSprinting()
                && mc.thePlayer.getFoodStats().getFoodLevel() > 6
                && !mc.thePlayer.isCollidedHorizontally) {
            mc.thePlayer.setSprinting(true);
        }
    }
}
