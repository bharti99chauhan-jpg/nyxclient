package com.aquastrike.module.modules.misc;

import com.aquastrike.event.EventTarget;
import com.aquastrike.event.events.EventSendPacket;
import com.aquastrike.module.Category;
import com.aquastrike.module.Module;
import com.aquastrike.module.setting.ListSetting;
import net.minecraft.network.play.client.C00PacketKeepAlive;
import net.minecraft.network.play.client.C03PacketPlayer;

public class Disabler extends Module {

    private final ListSetting mode = add(
            new ListSetting("Mode", "Polar", "Polar", "Generic"));

    public Disabler() { super("Disabler", Category.MISC); }

    @EventTarget
    public void onPacket(EventSendPacket event) {
        if (mode.is("Polar")) {
            // Drop keep-alive packets — Polar struggles to track state
            if (event.getPacket() instanceof C00PacketKeepAlive) {
                event.setCancelled(true);
            }
        } else if (mode.is("Generic")) {
            // Spam extra position packets to confuse AC
        }
    }
}
