package com.aquastrike.module.modules.misc;

import com.aquastrike.event.EventTarget;
import com.aquastrike.event.events.EventSendPacket;
import com.aquastrike.module.Category;
import com.aquastrike.module.Module;
import net.minecraft.network.Packet;

import java.util.ArrayList;
import java.util.List;

public class Blink extends Module {

    private final List<Packet<?>> buffer = new ArrayList<>();

    public Blink() { super("Blink", Category.MISC); }

    @EventTarget
    public void onPacket(EventSendPacket event) {
        // Buffer all outgoing position/motion packets
        buffer.add(event.getPacket());
        event.setCancelled(true);
    }

    @Override
    protected void onDisable() {
        super.onDisable();
        // Flush buffered packets on disable
        for (Packet<?> p : buffer) {
            mc.getNetHandler().addToSendQueue(p);
        }
        buffer.clear();
    }
}
