package com.aquastrike.module.modules.movement;

import com.aquastrike.event.EventTarget;
import com.aquastrike.event.events.EventMotion;
import com.aquastrike.module.Category;
import com.aquastrike.module.Module;
import com.aquastrike.module.setting.NumberSetting;

public class BHop extends Module {

    private final NumberSetting speed = add(new NumberSetting("Speed", 1.0, 0.1, 3.0, 0.05));

    public BHop() { super("BHop", Category.MOVEMENT); }

    @EventTarget
    public void onMotion(EventMotion event) {
        if (!event.isPre()) return;
        if (mc.thePlayer.onGround && mc.thePlayer.movementInput.moveForward != 0) {
            mc.thePlayer.jump();
        }
        if (!mc.thePlayer.onGround) {
            double yaw = Math.toRadians(mc.thePlayer.rotationYaw);
            double f   = mc.thePlayer.movementInput.moveForward;
            double s   = mc.thePlayer.movementInput.moveStrafe;
            if (f != 0 || s != 0) {
                mc.thePlayer.motionX = (-Math.sin(yaw) * f + Math.cos(yaw) * s) * speed.getValue();
                mc.thePlayer.motionZ = ( Math.cos(yaw) * f + Math.sin(yaw) * s) * speed.getValue();
            }
        }
    }
}
