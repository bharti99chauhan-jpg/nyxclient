package com.aquastrike.module.modules.combat;

import com.aquastrike.event.EventTarget;
import com.aquastrike.event.events.EventMotion;
import com.aquastrike.module.Category;
import com.aquastrike.module.Module;
import com.aquastrike.module.setting.ListSetting;
import net.minecraft.network.play.client.C03PacketPlayer;

public class Criticals extends Module {

    private final ListSetting mode = add(new ListSetting("Mode", "Packet", "Packet", "Jump"));

    public Criticals() { super("Criticals", Category.COMBAT); }

    @EventTarget
    public void onMotion(EventMotion event) {
        if (!event.isPre()) return;
        if (mc.thePlayer.onGround && mc.thePlayer.ridingEntity == null) {
            if (mode.is("Packet")) {
                // Send micro-jump packets so the server believes we're falling
                mc.getNetHandler().addToSendQueue(new C03PacketPlayer.Position(
                        mc.thePlayer.posX,
                        mc.thePlayer.posY + 0.0625,
                        mc.thePlayer.posZ,
                        false));
                mc.getNetHandler().addToSendQueue(new C03PacketPlayer.Position(
                        mc.thePlayer.posX,
                        mc.thePlayer.posY,
                        mc.thePlayer.posZ,
                        false));
            } else {
                // Actual jump
                mc.thePlayer.jump();
            }
        }
    }
}
