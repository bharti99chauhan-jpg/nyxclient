package com.aquastrike;

import com.aquastrike.event.EventBus;
import com.aquastrike.module.ModuleManager;
import com.aquastrike.gui.ClickGUI;
import net.minecraft.client.Minecraft;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;

@Mod(modid = AquaStrike.MODID, name = AquaStrike.NAME, version = AquaStrike.VERSION)
public class AquaStrike {

    public static final String MODID   = "aquastrike";
    public static final String NAME    = "Vape";
    public static final String VERSION = "4.0";

    public static AquaStrike INSTANCE;

    public static EventBus     eventBus;
    public static ModuleManager moduleManager;
    public static ClickGUI      clickGUI;

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        INSTANCE = this;

        eventBus      = new EventBus();
        moduleManager = new ModuleManager();
        clickGUI      = new ClickGUI();

        // Register the Forge tick / render listeners
        MinecraftForge.EVENT_BUS.register(moduleManager);
    }

    @Mod.EventHandler
    public void postInit(FMLPostInitializationEvent event) {
        // nothing needed post-init for now
    }

    public static Minecraft mc() {
        return Minecraft.getMinecraft();
    }
}
